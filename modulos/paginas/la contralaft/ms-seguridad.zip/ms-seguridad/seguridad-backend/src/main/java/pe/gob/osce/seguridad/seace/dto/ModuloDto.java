package pe.gob.osce.seguridad.seace.dto;

import java.util.Date;
import java.util.List;

import pe.gob.osce.seguridad.utils.DataTransferObjectUtil;

public class ModuloDto extends DataTransferObjectUtil {

	private static final long serialVersionUID = 1L;

	private Long id;

    private String nombre;

    private String descripcion;

    private String estado;

    private Date fechaCreacion;

    private String usuarioCreacion;

    private Date ultimaFechaModificacion;

    private String ultimoUsuarioModificacion;

    private List<PrivilegioDto> listaPrivilegio;

    private List<RolDto> listaRol;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    @Override
    public Date getFechaCreacion() {
        return fechaCreacion;
    }

    @Override
    public void setFechaCreacion(Date fechaCreacion) {
        this.fechaCreacion = fechaCreacion;
    }

    public String getUsuarioCreacion() {
        return usuarioCreacion;
    }

    public void setUsuarioCreacion(String usuarioCreacion) {
        this.usuarioCreacion = usuarioCreacion;
    }

    public Date getUltimaFechaModificacion() {
        return ultimaFechaModificacion;
    }

    public void setUltimaFechaModificacion(Date ultimaFechaModificacion) {
        this.ultimaFechaModificacion = ultimaFechaModificacion;
    }

    public String getUltimoUsuarioModificacion() {
        return ultimoUsuarioModificacion;
    }

    public void setUltimoUsuarioModificacion(String ultimoUsuarioModificacion) {
        this.ultimoUsuarioModificacion = ultimoUsuarioModificacion;
    }

    public List<PrivilegioDto> getListaPrivilegio() {
        return listaPrivilegio;
    }

    public void setListaPrivilegio(List<PrivilegioDto> listaPrivilegio) {
        this.listaPrivilegio = listaPrivilegio;
    }

    public List<RolDto> getListaRol() {
        return listaRol;
    }

    public void setListaRol(List<RolDto> listaRol) {
        this.listaRol = listaRol;
    }
}
