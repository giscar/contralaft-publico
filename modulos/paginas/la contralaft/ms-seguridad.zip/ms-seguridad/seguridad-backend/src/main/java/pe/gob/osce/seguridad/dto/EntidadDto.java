package pe.gob.osce.seguridad.dto;

import java.io.Serializable;

public class EntidadDto implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String idEntidad;
	private String nombreEntidad;
	public String getIdEntidad() {
		return idEntidad;
	}
	public void setIdEntidad(String idEntidad) {
		this.idEntidad = idEntidad;
	}
	public String getNombreEntidad() {
		return nombreEntidad;
	}
	public void setNombreEntidad(String nombreEntidad) {
		this.nombreEntidad = nombreEntidad;
	}
	
	
}
