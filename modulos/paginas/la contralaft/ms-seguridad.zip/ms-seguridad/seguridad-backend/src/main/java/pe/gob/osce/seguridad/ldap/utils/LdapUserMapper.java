package pe.gob.osce.seguridad.ldap.utils;


import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.SearchControls;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.ldap.core.AttributesMapper;
import org.springframework.ldap.core.DirContextAdapter;
import org.springframework.ldap.core.DirContextOperations;
import org.springframework.ldap.core.LdapTemplate;
import org.springframework.ldap.filter.EqualsFilter;
import org.springframework.ldap.filter.Filter;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.ldap.userdetails.LdapUserDetails;
import org.springframework.security.ldap.userdetails.LdapUserDetailsImpl;
import org.springframework.security.ldap.userdetails.LdapUserDetailsMapper;
import org.springframework.security.ldap.userdetails.UserDetailsContextMapper;
import org.springframework.stereotype.Service;

import pe.gob.osce.seguridad.ldap.dto.AttibuteUsuarioLdapDTO;
import pe.gob.osce.seguridad.ldap.dto.UsuarioLdapDTO;

@Service
public class LdapUserMapper {

	@Autowired
	private LdapTemplate ldapTemplate;
	
	private UsuarioLdapDTO usuarioLdap;
	
	
	public UsuarioLdapDTO getDetailUserLdap(String username) throws NamingException {
		
		final Filter filter= new EqualsFilter("uid", username);
		usuarioLdap = new UsuarioLdapDTO();
		
		/*
		
		ldapTemplate.search("", filter.encode(),
                new AttributesMapper() {
                       @Override
                       public Object mapFromAttributes(Attributes attr) throws NamingException {
                            NamingEnumeration<String> namingEnumeration = attr.getIDs();
                            while (namingEnumeration.hasMoreElements()) {
                                 String attributeName= (String) namingEnumeration.nextElement();
                                 
                                 switch(attributeName) {
                                 	case "givenname":
                                 		//Pair<Integer, String> simplePair = new Pair<>(42, "Second");
                                 		//Hashtable<String, Object> obj= new Hashtable<String, Object>();
                                 		                                 		
                                 		attibuteUsuarioLdap.setGivenname(attr.get(attributeName).toString());
                                 		                             		
                                 		break;
                                 }
                                 System.out.println(attributeName+" = "+attr.get(attributeName));
                            }
                            return null;
                       }
             });
		
		*/
		
		
		List<Map<String, List<String>>> searchResultList = ldapTemplate.search("", filter.encode(), new AttributesMapper<Map<String, List<String>>>() {
	        @Override
	        public Map<String, List<String>> mapFromAttributes(Attributes attributes) throws NamingException {
	            Map<String, List<String>> attrsMap = new HashMap<>();
	            NamingEnumeration<String> attrIdEnum = attributes.getIDs();
	            while (attrIdEnum.hasMoreElements()) {
	                // Get attribute id:
	                String attrId = attrIdEnum.next();
	                // Get all attribute values:
	                Attribute attr = attributes.get(attrId);
	                NamingEnumeration<?> attrValuesEnum = attr.getAll();
	                while (attrValuesEnum.hasMore()) {
	                    if (!attrsMap.containsKey(attrId))
	                        attrsMap.put(attrId, new ArrayList<String>()); 
	                    attrsMap.get(attrId).add(attrValuesEnum.next().toString());
	                }
	            }
	            return attrsMap;
	        }
	    });
		
		for (Map<String, List<String>> attrsMap : searchResultList) {
			for (String objectClass :attrsMap.get("uid")) {
				usuarioLdap.setUid(objectClass);
		    }
			for (String objectClass :attrsMap.get("mail")) {
				usuarioLdap.setMail(objectClass);
		    }
			for (String objectClass :attrsMap.get("givenname")) {
				usuarioLdap.setGivenname(objectClass);
		    }
			for (String objectClass :attrsMap.get("displayname")) {
				usuarioLdap.setDisplayname(objectClass);
		    }
			for (String objectClass :attrsMap.get("sn")) {
				usuarioLdap.setSn(objectClass);
		    }
			for (String objectClass :attrsMap.get("cn")) {
				usuarioLdap.setCn(objectClass);
		    }
		}
		
		
		return usuarioLdap;
		
		
	}
	
	

}
