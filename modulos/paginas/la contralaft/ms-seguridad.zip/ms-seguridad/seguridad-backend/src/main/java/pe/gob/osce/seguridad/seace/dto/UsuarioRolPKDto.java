package pe.gob.osce.seguridad.seace.dto;

import pe.gob.osce.seguridad.utils.DataTransferObjectUtil;

public class UsuarioRolPKDto extends DataTransferObjectUtil {

	private static final long serialVersionUID = 1L;

    private Long idPersona;

    private Long idPerfil;

    private Long idRol;

    private Long idOrganismo;

    public Long getIdPersona() {
        return idPersona;
    }

    public void setIdPersona(Long idPersona) {
        this.idPersona = idPersona;
    }

    public Long getIdPerfil() {
        return idPerfil;
    }

    public void setIdPerfil(Long idPerfil) {
        this.idPerfil = idPerfil;
    }

    public Long getIdRol() {
        return idRol;
    }
    public void setIdRol(Long idRol) {
        this.idRol = idRol;
    }

    public Long getIdOrganismo() {
        return idOrganismo;
    }

    public void setIdOrganismo(Long idOrganismo) {
        this.idOrganismo = idOrganismo;
    }
}	
