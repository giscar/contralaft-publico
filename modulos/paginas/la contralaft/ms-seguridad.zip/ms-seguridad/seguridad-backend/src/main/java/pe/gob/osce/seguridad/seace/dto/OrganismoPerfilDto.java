package pe.gob.osce.seguridad.seace.dto;

import java.util.List;

import pe.gob.osce.seguridad.utils.DataTransferObjectUtil;


public class OrganismoPerfilDto extends DataTransferObjectUtil {

	private static final long serialVersionUID = 1L;

	private Long id;

    private OrganismoDto organismo;

    private PerfilDto perfil;

    private List<UsuarioOrganismoDto> listaUsuarioOrganismo;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public OrganismoDto getOrganismo() {
        return organismo;
    }

    public void setOrganismo(OrganismoDto organismo) {
        this.organismo = organismo;
    }

    public PerfilDto getPerfil() {
        return perfil;
    }

    public void setPerfil(PerfilDto perfil) {
        this.perfil = perfil;
    }

    public List<UsuarioOrganismoDto> getListaUsuarioOrganismo() {
        return listaUsuarioOrganismo;
    }

    public void setListaUsuarioOrganismo(
            List<UsuarioOrganismoDto> listaUsuarioOrganismo) {
        this.listaUsuarioOrganismo = listaUsuarioOrganismo;
    }
}
