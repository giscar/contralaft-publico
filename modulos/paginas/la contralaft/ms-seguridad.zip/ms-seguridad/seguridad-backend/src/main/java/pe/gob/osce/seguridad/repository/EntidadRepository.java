package pe.gob.osce.seguridad.repository;

import java.util.List;

public interface EntidadRepository{

	List<Object[]> buscarEntidadesxOID(String oid);
	List<Object[]> obtenerTodasEntidades();
	
}
