package pe.gob.osce.seguridad.seace.dto;

import java.util.Date;
import java.util.List;

import pe.gob.osce.seguridad.utils.DataTransferObjectUtil;

public class UsuarioDto extends DataTransferObjectUtil {
    
	private static final long serialVersionUID = 1L;
	
	private Long id;
    
    private String codigoOID;
    
    private String codigoUsuario;
    
    private String clave;
    
    private String estado;
    
    private int indicadorClaveTemporal;
    
    private Date fechaCreacion;
    
    private String usuarioCreacion; 
    
    private Date ultimaFechaModificacion;
    
    private String ultimoUsuarioModificacion;
    
    private Date ultimaModificacionPass;    

    private String razonSocial;
    
    private Long codConsucode;
    
    private Long idOrgan;
    
    private PersonaDto persona;
    
    private List<UsuarioOrganismoDto> listaUsuarioOrganismo;


    public String getCodigoOID() {
        return codigoOID;
    }

    public void setCodigoOID(String codigoOID) {
        this.codigoOID = codigoOID;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public int getIndicadorClaveTemporal() {
        return indicadorClaveTemporal;
    }

    public void setIndicadorClaveTemporal(int indicadorClaveTemporal) {
        this.indicadorClaveTemporal = indicadorClaveTemporal;
    }

    @Override
    public Date getFechaCreacion() {
        return fechaCreacion;
    }

    public void setFechaCreacion(Date fechaCreacionP) {
        this.fechaCreacion = fechaCreacionP;
    }

    public String getUsuarioCreacion() {
        return usuarioCreacion;
    }

    public void setUsuarioCreacion(String usuarioCreacionP) {
        this.usuarioCreacion = usuarioCreacionP;
    }

    public Date getUltimaFechaModificacion() {
        return ultimaFechaModificacion;
    }

    public void setUltimaFechaModificacion(Date ultimaFechaModificacionP) {
        this.ultimaFechaModificacion = ultimaFechaModificacionP;
    }

    public String getUltimoUsuarioModificacion() {
        return ultimoUsuarioModificacion;
    }

    public void setUltimoUsuarioModificacion(String ultimoUsuarioModificacionP) {
        this.ultimoUsuarioModificacion = ultimoUsuarioModificacionP;
    }

    public List<UsuarioOrganismoDto> getListaUsuarioOrganismo() {
        return listaUsuarioOrganismo;
    }

    public void setListaUsuarioOrganismo(
            List<UsuarioOrganismoDto> listaUsuarioOrganismo) {
        this.listaUsuarioOrganismo = listaUsuarioOrganismo;
    }

    public String getClave() {
        return clave;
    }

    public void setClave(String clave) {
        this.clave = clave;
    }

	public PersonaDto getPersona() {
		return persona;
	}

	public void setPersona(PersonaDto persona) {
		this.persona = persona;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}
	

	public Date getUltimaModificacionPass() {
		return ultimaModificacionPass;
	}

	public void setUltimaModificacionPass(Date ultimaModificacionPass) {
		this.ultimaModificacionPass = ultimaModificacionPass;
	}

	public String getRazonSocial() {
		return razonSocial;
	}

	public void setRazonSocial(String razonSocial) {
		this.razonSocial = razonSocial;
	}

	public Long getCodConsucode() {
		return codConsucode;
	}

	public void setCodConsucode(Long codConsucode) {
		this.codConsucode = codConsucode;
	}

	public Long getIdOrgan() {
		return idOrgan;
	}

	public void setIdOrgan(Long idOrgan) {
		this.idOrgan = idOrgan;
	}

	public String getCodigoUsuario() {
		return codigoUsuario;
	}

	public void setCodigoUsuario(String codigoUsuario) {
		this.codigoUsuario = codigoUsuario;
	}

	
}
