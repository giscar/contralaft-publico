package pe.gob.osce.seguridad.seace.dto;

import java.util.Date;
import java.util.List;

import pe.gob.osce.seguridad.utils.DataTransferObjectUtil;


public class UbigeoDto extends DataTransferObjectUtil {

	private static final long serialVersionUID = 1L;

	private Long id;
 
    private String codigo;
    
    private String descripcion;
   
    private Date fechaCreacion;
 
    private String usuarioCreacion;
    
    private Date ultimaFechaModificacion;
  
    private String ultimoUsuarioModificacion;

    private String idCodSeace2;
	
	private Long idCodRNP;
    
    private UbigeoDto ubigeo;
   
    private List<UbigeoDto> listaUbigeo;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }
    
    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    @Override
    public Date getFechaCreacion() {
        return fechaCreacion;
    }

    @Override
    public void setFechaCreacion(Date fechaCreacion) {
        this.fechaCreacion = fechaCreacion;
    }

    public String getUsuarioCreacion() {
        return usuarioCreacion;
    }

    public void setUsuarioCreacion(String usuarioCreacion) {
        this.usuarioCreacion = usuarioCreacion;
    }

    public Date getUltimaFechaModificacion() {
        return ultimaFechaModificacion;
    }

    public void setUltimaFechaModificacion(Date ultimaFechaModificacion) {
        this.ultimaFechaModificacion = ultimaFechaModificacion;
    }

    public String getUltimoUsuarioModificacion() {
        return ultimoUsuarioModificacion;
    }

    public void setUltimoUsuarioModificacion(String ultimoUsuarioModificacion) {
        this.ultimoUsuarioModificacion = ultimoUsuarioModificacion;
    }

    public String getIdCodSeace2() {
		return idCodSeace2;
	}

	public void setIdCodSeace2(String idCodSeace2) {
		this.idCodSeace2 = idCodSeace2;
	}

	public Long getIdCodRNP() {
		return idCodRNP;
	}

	public void setIdCodRNP(Long idCodRNP) {
		this.idCodRNP = idCodRNP;
	}

    public UbigeoDto getUbigeo() {
        return ubigeo;
    }

    public void setUbigeo(UbigeoDto ubigeo) {
        this.ubigeo = ubigeo;
    }

    public List<UbigeoDto> getListaUbigeo() {
        return listaUbigeo;
    }

    public void setListaUbigeo(List<UbigeoDto> listaUbigeo) {
        this.listaUbigeo = listaUbigeo;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }
}
