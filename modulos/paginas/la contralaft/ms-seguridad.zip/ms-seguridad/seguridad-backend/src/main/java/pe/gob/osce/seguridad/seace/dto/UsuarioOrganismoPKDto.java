package pe.gob.osce.seguridad.seace.dto;

import pe.gob.osce.seguridad.utils.DataTransferObjectUtil;

public class UsuarioOrganismoPKDto extends DataTransferObjectUtil {

	private static final long serialVersionUID = 1L;

	private Long idPersona;

    private Long idOrganismo;

    public Long getIdPersona() {
        return idPersona;
    }

    public void setIdPersona(Long idPersona) {
        this.idPersona = idPersona;
    }

    public Long getIdOrganismo() {
        return idOrganismo;
    }

    public void setIdOrganismo(Long idOrganismo) {
        this.idOrganismo = idOrganismo;
    }
}
