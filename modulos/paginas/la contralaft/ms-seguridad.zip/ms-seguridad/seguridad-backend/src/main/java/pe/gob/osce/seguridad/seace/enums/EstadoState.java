package pe.gob.osce.seguridad.seace.enums;
import java.util.ArrayList;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;


public enum EstadoState {

	ACTIVO("ACTIV", "ACTIVO"),
	INACTIVO("INACT", "INACTIVO");

	private static final List<EstadoState> list = new ArrayList<EstadoState>();

	private static final Map<String, EstadoState> lookup = new HashMap<String, EstadoState>();

	static {
		for (EstadoState s : EnumSet.allOf(EstadoState.class)) {
			list.add(s);
			lookup.put(s.getKey(), s);
		}

	}
	
	private String key;
	
	private String value;

	private EstadoState(String key, String value) {
		this.key = key;
		this.value = value;
	}

	public String getKey() {
		return key;
	}

	public String getValue() {
		return value;
	}

	public String getDescription(Locale locale) {
		return this.getValue();
	}

	public static EstadoState get(String key) {
		return lookup.get(key);
	}
}
