package pe.gob.osce.seguridad.repository.impl;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import pe.gob.osce.seguridad.repository.EntidadRepository;
import pe.gob.osce.seguridad.repository.PrivilegioRepository;
import pe.gob.osce.seguridad.seace.dto.PrivilegioDto;
import pe.gob.osce.seguridad.utils.DateUtil;


@Repository
public class PrivilegioRepositoryImpl implements PrivilegioRepository{

	@PersistenceContext
    private EntityManager em;
	
	@SuppressWarnings("unchecked")
	@Override
	@Transactional(readOnly=true)
	public List<PrivilegioDto> obtenerPrivilegiosByUsuario(Long idModulo, Long idRol, Long idOrganismo, String uid){
		
		List<PrivilegioDto> result = new ArrayList<PrivilegioDto>();
		StringBuilder sbQuery = new StringBuilder();
		//sbQuery.append("SELECT DISTINCT PRV.C_ACCION, PRV.C_NOMPRV, PRV.C_ESTADO, DRU.D_FECCRE,MOD.C_NOMMOD ");
		sbQuery.append("SELECT DISTINCT PRV.C_ACCION, PRV.C_NOMPRV ");
		sbQuery.append("  FROM ADM.TBL_ADM_USU USU, ADM.DET_ADM_USU_ORG UOR, ADM.DET_ADM_ROL_USU DRU, ADM.TBL_ADM_ROL ROL, ADM.TBL_ADM_PRV PRV, ADM.DET_ADM_PRV_ROL PRO, ADM.TBL_ADM_MOD MOD");
		sbQuery.append(" WHERE USU.N_ID_PERS = DRU.N_ID_PERS ");
		sbQuery.append("   AND UOR.N_ID_PERS = USU.N_ID_PERS  ");
		sbQuery.append("   AND UOR.N_ID_ORGAN = DRU.N_ID_ORGAN ");
		sbQuery.append("   AND DRU.N_ID_ROL = ROL.N_ID_ROL ");
		sbQuery.append("   AND PRO.N_ID_ROL = ROL.N_ID_ROL ");
		sbQuery.append("   AND PRO.N_ID_PRIVILEGIO = PRV.N_ID_PRIVILEGIO ");
		sbQuery.append("   AND PRV.N_ID_MODULO= MOD.N_ID_MODULO ");
		sbQuery.append("   AND MOD.N_ID_MODULO = :idModulo ");
		if (idRol != null && idRol.intValue() != -1) {
			sbQuery.append("   AND ROL.N_ID_ROL= :idRol ");
		}
		sbQuery.append("   AND UOR.N_ID_ORGAN = :idOrganismo ");
		sbQuery.append("   AND USU.C_CODOID = :uid ");
		
		Query query = em.createNativeQuery(sbQuery.toString());
		
		query.setParameter("idModulo",idModulo);
		
		if (idRol != null && idRol.intValue() != -1) {
			query.setParameter("idRol",idRol);
		}
		query.setParameter("idOrganismo",idOrganismo);
		query.setParameter("uid",uid);
		
		List<Object[]> listRpt = query.getResultList();
	
		for (Object[] obj : listRpt) {
			PrivilegioDto dto = new PrivilegioDto();
			dto.setAccion(String.valueOf(obj[0]));
			dto.setNombre(String.valueOf(obj[1]));
			//dto.setEstado(String.valueOf(obj[2]));
			//dto.setFechaCreacion(DateUtil.getDateInstanceOf(obj[3]));
			//dto.setNombreModulo(String.valueOf(obj[4]));
			result.add(dto);
		}
		return result;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	@Transactional(readOnly=true)
	public List<String> obtenerPrivilegiosByUsuarioSoloAcciones(Long idModulo, Long idRol, Long idOrganismo, String uid){
		
		List<String> result = new ArrayList<String>();
		StringBuilder sbQuery = new StringBuilder();
		sbQuery.append("SELECT DISTINCT PRV.C_ACCION ");
		sbQuery.append("  FROM ADM.TBL_ADM_USU USU, ADM.DET_ADM_USU_ORG UOR, ADM.DET_ADM_ROL_USU DRU, ADM.TBL_ADM_ROL ROL, ADM.TBL_ADM_PRV PRV, ADM.DET_ADM_PRV_ROL PRO, ADM.TBL_ADM_MOD MOD");
		sbQuery.append(" WHERE USU.N_ID_PERS = DRU.N_ID_PERS ");
		sbQuery.append("   AND UOR.N_ID_PERS = USU.N_ID_PERS  ");
		sbQuery.append("   AND UOR.N_ID_ORGAN = DRU.N_ID_ORGAN ");
		sbQuery.append("   AND DRU.N_ID_ROL = ROL.N_ID_ROL ");
		sbQuery.append("   AND PRO.N_ID_ROL = ROL.N_ID_ROL ");
		sbQuery.append("   AND PRO.N_ID_PRIVILEGIO = PRV.N_ID_PRIVILEGIO ");
		sbQuery.append("   AND PRV.N_ID_MODULO= MOD.N_ID_MODULO ");
		sbQuery.append("   AND MOD.N_ID_MODULO = :idModulo ");
		if (idRol != null && idRol.intValue() != -1) {
			sbQuery.append("   AND ROL.N_ID_ROL= :idRol ");
		}
		sbQuery.append("   AND UOR.N_ID_ORGAN = :idOrganismo ");
		sbQuery.append("   AND USU.C_CODOID = :uid ");
		
		Query query = em.createNativeQuery(sbQuery.toString());
		
		query.setParameter("idModulo",idModulo);
		
		if (idRol != null && idRol.intValue() != -1) {
			query.setParameter("idRol",idRol);
		}
		query.setParameter("idOrganismo",idOrganismo);
		query.setParameter("uid",uid);
		
		List<Object[]> listRpt = query.getResultList();
	
		for (Object obj : listRpt) {
			result.add(String.valueOf(obj));
		}
		return result;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	@Transactional(readOnly=true)
	public List<String> obtenerPrivilegiosByUsuarioSoloAccionesTodasEntidades(Long idModulo, String uid){
		
		List<String> result = new ArrayList<String>();
		StringBuilder sbQuery = new StringBuilder();
		sbQuery.append("SELECT DISTINCT PRV.C_ACCION ");
		sbQuery.append("FROM ADM.TBL_ADM_USU USU ");
		sbQuery.append("INNER JOIN ADM.DET_ADM_ROL_USU DRU ON (USU.N_ID_PERS = DRU.N_ID_PERS) ");
		sbQuery.append("INNER JOIN ADM.TBL_ADM_ROL ROL ON (DRU.N_ID_ROL = ROL.N_ID_ROL) ");
		sbQuery.append("INNER JOIN ADM.TBL_ADM_MOD MOD ON (ROL.N_ID_MODULO=MOD.N_ID_MODULO) ");
		sbQuery.append("INNER JOIN ADM.DET_ADM_PRV_ROL PRO ON (PRO.N_ID_ROL = ROL.N_ID_ROL ) ");
		sbQuery.append("INNER JOIN ADM.TBL_ADM_PRV PRV ON (PRO.N_ID_PRIVILEGIO = PRV.N_ID_PRIVILEGIO) ");
		sbQuery.append("WHERE USU.C_CODOID = :uid ");
		//sbQuery.append("AND MOD.N_ID_MODULO = :idModulo ");
		
		Query query = em.createNativeQuery(sbQuery.toString());
		query.setParameter("uid",uid);
		//query.setParameter("idModulo",idModulo);
		
		List<Object[]> listRpt = query.getResultList();
	
		for (Object obj : listRpt) {
			result.add(String.valueOf(obj));
		}
		return result;
	}
	
}
