package pe.gob.osce.seguridad.seace.dto;

import java.util.Date;
import java.util.List;

import pe.gob.osce.seguridad.utils.DataTransferObjectUtil;



public class UsuarioOrganismoDto extends DataTransferObjectUtil {

	private static final long serialVersionUID = 1L;

	protected UsuarioOrganismoPKDto usuarioOrganismoPK;

	private String condicionLaboral;

	private String otraCondicionLaboral;

	private String emailInstitucional;

	private String celularInstitucional;

	private String telefonoInstitucional;

	private String anexoInstitucional;

	private String faxInstitucional;

	private String cargo;

	private Integer indicadorAdministradorEntidad;

	private String estado;

	private Date fechaCreacion;

	private String usuarioCreacion;

	private Date ultimaFechaModificacion;

	private String ultimoUsuarioModificacion;

	private Date ultimaFechaActivacion;

	private String ultimoUsuarioActivacion;

	private Date ultimaFechaDesactivacion;

	private String ultimoUsuarioDesactivacion;

	private UbigeoDto ubigeo;

	private UsuarioDto usuario;

	private UnidadOrganicaDto unidadOrganica;

	private OrganismoPerfilDto organismoPerfil;

	private OrganismoDto organismo;

	private List<UsuarioRolDto> listaUsuarioRol;

	private Long idAuditoriaAsociada;

	public UsuarioOrganismoPKDto getUsuarioOrganismoPK() {
		return usuarioOrganismoPK;
	}

	public void setUsuarioOrganismoPK(UsuarioOrganismoPKDto usuarioOrganismoPK) {
		this.usuarioOrganismoPK = usuarioOrganismoPK;
	}

	public String getCondicionLaboral() {
		return condicionLaboral;
	}

	public void setCondicionLaboral(String condicionLaboral) {
		this.condicionLaboral = condicionLaboral;
	}

	public String getOtraCondicionLaboral() {
		return otraCondicionLaboral;
	}

	public void setOtraCondicionLaboral(String otraCondicionLaboral) {
		this.otraCondicionLaboral = otraCondicionLaboral;
	}

	public String getEmailInstitucional() {
		return emailInstitucional;
	}

	public void setEmailInstitucional(String emailInstitucional) {
		this.emailInstitucional = emailInstitucional;
	}

	public String getCelularInstitucional() {
		return celularInstitucional;
	}

	public void setCelularInstitucional(String celularInstitucional) {
		this.celularInstitucional = celularInstitucional;
	}
	
	public String getTelefonoInstitucional() {
		return telefonoInstitucional;
	}

	public void setTelefonoInstitucional(String telefonoInstitucional) {
		this.telefonoInstitucional = telefonoInstitucional;
	}

	public String getAnexoInstitucional() {
		return anexoInstitucional;
	}

	public void setAnexoInstitucional(String anexoInstitucional) {
		this.anexoInstitucional = anexoInstitucional;
	}

	public String getFaxInstitucional() {
		return faxInstitucional;
	}

	public void setFaxInstitucional(String faxInstitucional) {
		this.faxInstitucional = faxInstitucional;
	}

	public String getCargo() {
		return cargo;
	}

	public void setCargo(String cargo) {
		this.cargo = cargo;
	}

	public Integer getIndicadorAdministradorEntidad() {
		return indicadorAdministradorEntidad;
	}

	public void setIndicadorAdministradorEntidad(
			Integer indicadorAdministradorEntidad) {
		this.indicadorAdministradorEntidad = indicadorAdministradorEntidad;
	}

	public String getEstado() {
		return estado;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}

	@Override
	public Date getFechaCreacion() {
		return fechaCreacion;
	}

	@Override
	public void setFechaCreacion(Date fechaCreacion) {
		this.fechaCreacion = fechaCreacion;
	}

	public String getUsuarioCreacion() {
		return usuarioCreacion;
	}

	public void setUsuarioCreacion(String usuarioCreacion) {
		this.usuarioCreacion = usuarioCreacion;
	}

	public Date getUltimaFechaModificacion() {
		return ultimaFechaModificacion;
	}

	public void setUltimaFechaModificacion(Date ultimaFechaModificacion) {
		this.ultimaFechaModificacion = ultimaFechaModificacion;
	}

	public String getUltimoUsuarioModificacion() {
		return ultimoUsuarioModificacion;
	}

	public void setUltimoUsuarioModificacion(String ultimoUsuarioModificacion) {
		this.ultimoUsuarioModificacion = ultimoUsuarioModificacion;
	}

	public Date getUltimaFechaActivacion() {
		return ultimaFechaActivacion;
	}

	public void setUltimaFechaActivacion(Date ultimaFechaActivacion) {
		this.ultimaFechaActivacion = ultimaFechaActivacion;
	}

	public String getUltimoUsuarioActivacion() {
		return ultimoUsuarioActivacion;
	}

	public void setUltimoUsuarioActivacion(String ultimoUsuarioActivacion) {
		this.ultimoUsuarioActivacion = ultimoUsuarioActivacion;
	}

	public Date getUltimaFechaDesactivacion() {
		return ultimaFechaDesactivacion;
	}

	public void setUltimaFechaDesactivacion(Date ultimaFechaDesactivacion) {
		this.ultimaFechaDesactivacion = ultimaFechaDesactivacion;
	}

	public String getUltimoUsuarioDesactivacion() {
		return ultimoUsuarioDesactivacion;
	}

	public void setUltimoUsuarioDesactivacion(String ultimoUsuarioDesactivacion) {
		this.ultimoUsuarioDesactivacion = ultimoUsuarioDesactivacion;
	}

	public UbigeoDto getUbigeo() {
		return ubigeo;
	}

	public void setUbigeo(UbigeoDto ubigeo) {
		this.ubigeo = ubigeo;
	}

	public UsuarioDto getUsuario() {
		return usuario;
	}

	public void setUsuario(UsuarioDto usuario) {
		this.usuario = usuario;
	}

	public UnidadOrganicaDto getUnidadOrganica() {
		return unidadOrganica;
	}

	public void setUnidadOrganica(UnidadOrganicaDto unidadOrganica) {
		this.unidadOrganica = unidadOrganica;
	}

	public OrganismoDto getOrganismo() {
		return organismo;
	}

	public void setOrganismo(OrganismoDto organismo) {
		this.organismo = organismo;
	}

	public List<UsuarioRolDto> getListaUsuarioRol() {
		return listaUsuarioRol;
	}

	public void setListaUsuarioRol(List<UsuarioRolDto> listaUsuarioRol) {
		this.listaUsuarioRol = listaUsuarioRol;
	}

	public OrganismoPerfilDto getOrganismoPerfil() {
		return organismoPerfil;
	}

	public void setOrganismoPerfil(OrganismoPerfilDto organismoPerfil) {
		this.organismoPerfil = organismoPerfil;
	}

	public Long getIdAuditoriaAsociada() {
		return idAuditoriaAsociada;
	}

	public void setIdAuditoriaAsociada(Long idAuditoriaAsociada) {
		this.idAuditoriaAsociada = idAuditoriaAsociada;
	}
}
