package pe.gob.osce.seguridad.seace.enums;

import java.util.ArrayList;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;



public enum CondicionState {
	
	NO(0L, "NO"),
	
	SI(1L, "SI");

	private static final List<CondicionState> list = new ArrayList<CondicionState>();

	private static final Map<Long, CondicionState> lookup = new HashMap<Long, CondicionState>();

	static {
		for (CondicionState s : EnumSet.allOf(CondicionState.class)) {
			list.add(s);
			lookup.put(s.getKey(), s);
		}

	}

	private Long key;

	private String value;

	private CondicionState(Long key, String value) {
		this.key = key;
		this.value = value;
	}

	public Long getKey() {
		return key;
	}

	public String getValue() {
		return value;
	}

	public String getDescription(Locale locale) {
		return this.getValue();
	}

	public static CondicionState get(Long key) {
		return lookup.get(key);
	}
}
