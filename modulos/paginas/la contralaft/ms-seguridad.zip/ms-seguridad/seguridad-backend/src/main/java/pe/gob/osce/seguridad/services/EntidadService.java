package pe.gob.osce.seguridad.services;

import java.util.List;

import pe.gob.osce.seguridad.dto.EntidadDto;

public interface EntidadService {
	
	public List<EntidadDto> getListaEntidadesByOID(String username);
}
