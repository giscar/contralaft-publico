package pe.gob.osce.seguridad.jdbc.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="TBL_SEG_ROL", schema="SEG")
public class Rol implements Serializable {
	
	private static final long serialVersionUID = 1L;
	
	@Id
	@SequenceGenerator(name="SQ_N_ID_ROL", sequenceName="SQ_N_ID_ROL",schema="SEG", allocationSize = 1)
	@GeneratedValue(generator = "SQ_N_ID_ROL", strategy=GenerationType.SEQUENCE)
	@Column(name="N_ID_ROL")
	private Long idRol;
	
	@Column(name="C_NOM_ROL")
	private String nombreRol;
	
	@Column(name="C_DES_ROL")
	private String descripcionRol;
	
	@Column(name="N_EST_ROL")
	private Long estadoRol;
	
	@Column(name="N_EST_REGISTRO")
	private Long estadoRegistro;
	
	@Column(name="C_USU_REG")
	private String usuarioCreacion;
	
	@Column(name="D_FEC_REG")
	private Date fechaCreacion;
	
	@Column(name="C_USU_MOD")
	private String usuarioModificacion;
	
	@Column(name="D_FEC_MOD")
	private Date fechaModificacion;

	public Long getIdRol() {
		return idRol;
	}

	public void setIdRol(Long idRol) {
		this.idRol = idRol;
	}

	public String getNombreRol() {
		return nombreRol;
	}

	public void setNombreRol(String nombreRol) {
		this.nombreRol = nombreRol;
	}

	public String getDescripcionRol() {
		return descripcionRol;
	}

	public void setDescripcionRol(String descripcionRol) {
		this.descripcionRol = descripcionRol;
	}

	public Long getEstadoRol() {
		return estadoRol;
	}

	public void setEstadoRol(Long estadoRol) {
		this.estadoRol = estadoRol;
	}

	public Long getEstadoRegistro() {
		return estadoRegistro;
	}

	public void setEstadoRegistro(Long estadoRegistro) {
		this.estadoRegistro = estadoRegistro;
	}

	public String getUsuarioCreacion() {
		return usuarioCreacion;
	}

	public void setUsuarioCreacion(String usuarioCreacion) {
		this.usuarioCreacion = usuarioCreacion;
	}

	public Date getFechaCreacion() {
		return fechaCreacion;
	}

	public void setFechaCreacion(Date fechaCreacion) {
		this.fechaCreacion = fechaCreacion;
	}

	public String getUsuarioModificacion() {
		return usuarioModificacion;
	}

	public void setUsuarioModificacion(String usuarioModificacion) {
		this.usuarioModificacion = usuarioModificacion;
	}

	public Date getFechaModificacion() {
		return fechaModificacion;
	}

	public void setFechaModificacion(Date fechaModificacion) {
		this.fechaModificacion = fechaModificacion;
	}
	
	/*@ManyToMany(mappedBy = "rol")
	private List<UsuarioRol1> roles;*/
	
	

}
