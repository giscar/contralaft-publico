package pe.gob.osce.seguridad.seace.dto;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import pe.gob.osce.seguridad.seace.enums.CondicionState;
import pe.gob.osce.seguridad.seace.enums.EstadoState;
import pe.gob.osce.seguridad.utils.DataTransferObjectUtil;;


public class RolDto extends DataTransferObjectUtil {

	private static final long serialVersionUID = 1L;

    private Long id;

    private String codigoOID;

    private String nombre;

    private String descripcion;

    private String estado;

    private Date fechaCreacion;

    private String usuarioCreacion;

    private Date ultimaFechaModificacion;

    private String ultimoUsuarioModificacion;

    private Date ultimaFechaActivacion;

    private String ultimoUsuarioActivacion;

    private Date ultimaFechaDesactivacion;
    
    private String ultimoUsuarioDesactivacion;
    
    private ModuloDto modulo = new ModuloDto();

    private Long indicadorAdministrador;

    private List<PrivilegioRolDto> listaPrivilegioRol = new ArrayList<PrivilegioRolDto>();

    private List<PerfilRolDto> listaPerfilRol;

    private EstadoState estadoRol;

    private CondicionState condicionAdministrador;

    private boolean hidden;

    private String accion;
	
	/** La fecha accion. */
	private Date fechaAccion;
    
	/**
	 * Metodo para obtener la condicion de administrador de un Rol.
	 * 
	 * @return Retorna un CondicionState con la condicion de administrador del Rol.
	 */
    public CondicionState getCondicionAdministrador() {
        return condicionAdministrador;
    }

    /**
	 * Metodo para asignar la condicion de administrador de un Rol.
	 * 
	 * @param condicionAdministrador
	 *            Recibe un CondicionState con la condicion de administrador del Rol.
	 */
    public void setCondicionAdministrador(CondicionState condicionAdministrador) {
        this.condicionAdministrador = condicionAdministrador;
    }

    /**
	 * Metodo para asignar el indicador de administrador de un Rol.
	 * 
	 * @param indicadorAdministrador
	 *            Recibe un Long con el indicador de administrador del Rol.
	 */
    public void setcondicionAdministrador(Long indicadorAdministrador) {
        this.indicadorAdministrador = indicadorAdministrador;
    }

    /**
	 * Metodo para obtener el id de un Rol.
	 * 
	 * @return Retorna un Long con el id del Rol.
	 */
    public Long getId() {
    	return id;
        //return (id != null) ? (id.longValue() == 0) ? null : id : id;
    }

    /**
	 * Metodo para asignar el id de un Rol.
	 * 
	 * @param id
	 *            Recibe un Long con el id del Rol.
	 */
    public void setId(Long id) {
        this.id = id;
    }

    /**
	 * Metodo para obtener el codigo de un Rol.
	 * 
	 * @return Retorna un String con el codigo del Rol.
	 */
    public String getCodigoOID() {
        return codigoOID;
    }

    /**
	 * Metodo para asignar el codigo de un Rol.
	 * 
	 * @param codigoOID
	 *            Recibe un Long con el codigo del Rol.
	 */
    public void setCodigoOID(String codigoOID) {
        this.codigoOID = codigoOID;
    }

    /**
	 * Metodo para obtener el nombre de un Rol.
	 * 
	 * @return Retorna un String con el nombre del Rol.
	 */
    public String getNombre() {
        return nombre;
    }

    /**
	 * Metodo para asignar el nombre de un Rol.
	 * 
	 * @param nombre
	 *            Recibe un String con el nombre del Rol.
	 */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
	 * Metodo para obtener la descripcion de un Rol.
	 * 
	 * @return Retorna un String con la descripcion del Rol.
	 */
    public String getDescripcion() {
        return descripcion;
    }

    /**
	 * Metodo para asignar la descripcion de un Rol.
	 * 
	 * @param descripcion
	 *            Recibe un String con la descripcion del Rol.
	 */
    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    /**
	 * Metodo para obtener el estado de un Rol.
	 * 
	 * @return Retorna un String con el estado del Rol.
	 */
    public String getEstado() {
        return estado;
    }

    /**
	 * Metodo para asignar el estado de un Rol.
	 * 
	 * @param estado
	 *            Recibe un String con el estado del Rol.
	 */
    public void setEstado(String estado) {
        this.estadoRol = EstadoState.get(estado);
        this.estado = estado;
    }

    /**
	 * Metodo para obtener la fecha de creacion de un Rol.
	 * 
	 * @return Retorna un Date con la fecha de creacion del Rol.
	 */
    @Override
    public Date getFechaCreacion() {
        return fechaCreacion;
    }

    /**
	 * Metodo para asignar la fecha de creacion de un Rol.
	 * 
	 * @param fechaCreacion
	 *            Recibe un Date con la fecha de creacion del Rol.
	 */
    @Override
    public void setFechaCreacion(Date fechaCreacion) {
        this.fechaCreacion = fechaCreacion;
    }

    /**
	 * Metodo para obtener el usuario que creo el Rol.
	 * 
	 * @return Retorna un String con el usuario de creacion del Rol.
	 */
    public String getUsuarioCreacion() {
        return usuarioCreacion;
    }

    /**
	 * Metodo para asignar el usuario que crea el Rol.
	 * 
	 * @param usuarioCreacion
	 *            Recibe un String con el usuario de creacion del Rol.
	 */
    public void setUsuarioCreacion(String usuarioCreacion) {
        this.usuarioCreacion = usuarioCreacion;
    }

    /**
	 * Metodo para obtener la ultima fecha en que se modifica el Rol.
	 * 
	 * @return Retorna un Date con la ultima fecha de creacion del Rol.
	 */
    public Date getUltimaFechaModificacion() {
        return ultimaFechaModificacion;
    }

    /**
	 * Metodo para asignar la ultima fecha en que se modifica el Rol.
	 * 
	 * @param ultimaFechaModificacion
	 *            Recibe un Date con la ultima fecha de modificacion del Rol.
	 */
    public void setUltimaFechaModificacion(Date ultimaFechaModificacion) {
        this.ultimaFechaModificacion = ultimaFechaModificacion;
    }

    /**
	 * Metodo para obtener el ultimo usuario que modifica el Rol.
	 * 
	 * @return Retorna un String con el ultimo usuario que modifica el Rol.
	 */
    public String getUltimoUsuarioModificacion() {
        return ultimoUsuarioModificacion;
    }

    /**
	 * Metodo para asignar el ultimo usuario que modifica el Rol.
	 * 
	 * @param ultimoUsuarioModificacion
	 *            Recibe un String con el ultimo usuario que modifica el Rol.
	 */
    public void setUltimoUsuarioModificacion(String ultimoUsuarioModificacion) {
        this.ultimoUsuarioModificacion = ultimoUsuarioModificacion;
    }

    /**
	 * Metodo para obtener la ultima fecha en que se activa el Rol.
	 * 
	 * @return Retorna un Date con la ultima fecha en que se activa el Rol.
	 */
    public Date getUltimaFechaActivacion() {
        return ultimaFechaActivacion;
    }

    /**
	 * Metodo para asignar la ultima fecha en que se activa el Rol.
	 * 
	 * @param ultimaFechaActivacion
	 *            Recibe un Date con la ultima fecha de activacion del Rol.
	 */
    public void setUltimaFechaActivacion(Date ultimaFechaActivacion) {
        this.ultimaFechaActivacion = ultimaFechaActivacion;
    }

    /**
	 * Metodo para obtener el ultimo usuario que activa el Rol.
	 * 
	 * @return Retorna un String con el ultimo usuario que activa el Rol.
	 */
    public String getUltimoUsuarioActivacion() {
        return ultimoUsuarioActivacion;
    }

    /**
	 * Metodo para asignar el ultimo usuario que activa el Rol.
	 * 
	 * @param ultimoUsuarioActivacion
	 *            Recibe un String con el ultimo usuario que activa el Rol.
	 */
    public void setUltimoUsuarioActivacion(String ultimoUsuarioActivacion) {
        this.ultimoUsuarioActivacion = ultimoUsuarioActivacion;
    }

    /**
	 * Metodo para obtener la ultima fecha en que se desactiva el Rol.
	 * 
	 * @return Retorna un Date con la ultima fecha en que se desactiva el Rol.
	 */
    public Date getUltimaFechaDesactivacion() {
        return ultimaFechaDesactivacion;
    }

    /**
	 * Metodo para asignar la ultima fecha en que se desactiva el Rol.
	 * 
	 * @param ultimaFechaDesactivacion
	 *            Recibe un Date con la ultima fecha que desactiva el Rol.
	 */
    public void setUltimaFechaDesactivacion(Date ultimaFechaDesactivacion) {
        this.ultimaFechaDesactivacion = ultimaFechaDesactivacion;
    }

    /**
	 * Metodo para obtener el ultimo usuario en que se desactiva el Rol.
	 * 
	 * @return Retorna un Date con el ultimo usuario en que se desactiva el Rol.
	 */
    public String getUltimoUsuarioDesactivacion() {
        return ultimoUsuarioDesactivacion;
    }

    /**
	 * Metodo para asignar el ultimo usuario en que se desactiva el Rol.
	 * 
	 * @param ultimoUsuarioDesactivacion
	 *            Recibe un Date con el ultimo usuario que desactiva el Rol.
	 */
    public void setUltimoUsuarioDesactivacion(String ultimoUsuarioDesactivacion) {
        this.ultimoUsuarioDesactivacion = ultimoUsuarioDesactivacion;
    }

    /**
	 * Metodo para obtener el modulo de un Rol.
	 * 
	 * @return Retorna un ModuloDTO con el modulo del Rol.
	 */
    public ModuloDto getModulo() {
        return modulo;
    }

    /**
	 * Metodo para asignar el modulo de un Rol.
	 * 
	 * @param modulo
	 *            Recibe un ModuloDTO con el modulo del Rol.
	 */
    public void setModulo(ModuloDto modulo) {
        this.modulo = modulo;
    }

    /**
	 * Metodo para obtener la lista de Privilegios asignado a un Rol.
	 * 
	 * @return Retorna un List PrivilegioRolDTO con la lista Privilegios de un Rol.
	 */
    public List<PrivilegioRolDto> getListaPrivilegioRol() {
        return listaPrivilegioRol;
    }

    /**
	 * Metodo para asignar la lista de Privilegios a un Rol.
	 * 
	 * @param listaPrivilegioRol
	 *            Recibe un List PrivilegioRolDTO con la lista de Privilegios de un Rol.
	 */
    public void setListaPrivilegioRol(List<PrivilegioRolDto> listaPrivilegioRol) {
        this.listaPrivilegioRol = listaPrivilegioRol;
    }





    /**
	 * Metodo para obtener la lista de Perfil asignado a un Rol.
	 * 
	 * @return Retorna un List PerfilRolDTO con la lista de Perfiles de un Rol.
	 */
    public List<PerfilRolDto> getListaPerfilRol() {
        return listaPerfilRol;
    }

    /**
	 * Metodo para asignar la lista de Perfiles asignado a un Rol.
	 * 
	 * @param listaPerfilRol
	 *            Recibe un List PerfilRolDTO con la lista de Perfiles de un Rol.
	 */
    public void setListaPerfilRol(List<PerfilRolDto> listaPerfilRol) {
        this.listaPerfilRol = listaPerfilRol;
    }

    /**
	 * Metodo para obtener el indicador administrador de un Rol.
	 * 
	 * @return Retorna un ModuloDTO con el modulo del Rol.
	 */
    public Long getIndicadorAdministrador() {
        return indicadorAdministrador;
    }

   
    /**
     * Establece el indicador administrador.
     *
     * @param indicadorAdministrador el new indicador administrador
     */
    public void setIndicadorAdministrador(Long indicadorAdministrador) {
        this.condicionAdministrador = condicionAdministrador.get(indicadorAdministrador);
        this.indicadorAdministrador = indicadorAdministrador;
    }

    /**
	 * Metodo para obtener el estado de un Rol.
	 * 
	 * @return Retorna un EstadoState con el estado del Rol.
	 */
    public EstadoState getEstadoRol() {
        return estadoRol;
    }

    /**
	 * Metodo para asignar el estado de un Rol.
	 * 
	 * @param estadoRol
	 *            Recibe un Long con el estado del Rol.
	 */
    public void setEstadoRol(EstadoState estadoRol) {
        this.estadoRol = estadoRol;
    }

	
    /**
     * Comprueba si es hidden.
     *
     * @return true, si es hidden
     */
    public boolean isHidden() {
		return hidden;
	}

	
    /**
     * Establece el hidden.
     *
     * @param hidden el new hidden
     */
    public void setHidden(boolean hidden) {
		this.hidden = hidden;
	}

	/**
	 * Obtiene accion.
	 *
	 * @return accion
	 */
	public String getAccion() {
		return accion;
	}

    /**
     * Establece el accion.
     *
     * @param accion el new accion
     */
    public void setAccion(String accion) {
		this.accion = accion;
	}

	/**
	 * Obtiene fecha accion.
	 *
	 * @return fecha accion
	 */
	public Date getFechaAccion() {
		return fechaAccion;
	}
    
	/**
	 * Establece el fecha accion.
	 *
	 * @param fechaAccion el new fecha accion
	 */
	public void setFechaAccion(Date fechaAccion) {
		this.fechaAccion = fechaAccion;
	}
}