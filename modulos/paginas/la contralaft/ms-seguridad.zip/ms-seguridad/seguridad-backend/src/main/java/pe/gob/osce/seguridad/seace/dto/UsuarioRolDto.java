package pe.gob.osce.seguridad.seace.dto;

import java.util.Date;

import pe.gob.osce.seguridad.utils.DataTransferObjectUtil;

public class UsuarioRolDto extends DataTransferObjectUtil {


	private static final long serialVersionUID = 1L;

    protected UsuarioRolPKDto usuarioRolPK;

    private String estado;

    private Date fechaCreacion;
 
    private String usuarioCreacion;

    private Date ultimaFechaModificacion;

    private String ultimoUsuarioModificacion;

    private UsuarioOrganismoDto usuarioOrganismo;

    private PerfilRolDto perfilRol;

    private boolean hidden;

    public UsuarioRolPKDto getUsuarioRolPK() {
        return usuarioRolPK;
    }

    public void setUsuarioRolPK(UsuarioRolPKDto usuarioRolPK) {
        this.usuarioRolPK = usuarioRolPK;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    @Override
    public Date getFechaCreacion() {
        return fechaCreacion;
    }

    @Override
    public void setFechaCreacion(Date fechaCreacion) {
        this.fechaCreacion = fechaCreacion;
    }

    public String getUsuarioCreacion() {
        return usuarioCreacion;
    }

    public void setUsuarioCreacion(String usuarioCreacion) {
        this.usuarioCreacion = usuarioCreacion;
    }

    public Date getUltimaFechaModificacion() {
        return ultimaFechaModificacion;
    }

    public void setUltimaFechaModificacion(Date ultimaFechaModificacion) {
        this.ultimaFechaModificacion = ultimaFechaModificacion;
    }

    public String getUltimoUsuarioModificacion() {
        return ultimoUsuarioModificacion;
    }

    public void setUltimoUsuarioModificacion(String ultimoUsuarioModificacion) {
        this.ultimoUsuarioModificacion = ultimoUsuarioModificacion;
    }

    public UsuarioOrganismoDto getUsuarioOrganismo() {
        return usuarioOrganismo;
    }

    public void setUsuarioOrganismo(UsuarioOrganismoDto usuarioOrganismo) {
        this.usuarioOrganismo = usuarioOrganismo;
    }

    public PerfilRolDto getPerfilRol() {
        return perfilRol;
    }

    public void setPerfilRol(PerfilRolDto perfilRol) {
        this.perfilRol = perfilRol;
    }

	public boolean isHidden() {
		return hidden;
	}

	public void setHidden(boolean hidden) {
		this.hidden = hidden;
	}
}
