package pe.gob.osce.seguridad.oauth.config;

import java.util.Arrays;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.Ordered;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.oauth2.config.annotation.web.configuration.EnableResourceServer;
import org.springframework.security.oauth2.config.annotation.web.configuration.ResourceServerConfigurerAdapter;
import org.springframework.security.web.access.channel.ChannelProcessingFilter;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
import org.springframework.web.filter.CorsFilter;

import pe.gob.osce.seguridad.filters.EncodingFilter;

import org.springframework.boot.web.servlet.FilterRegistrationBean;

@Configuration
@EnableResourceServer
public class ResourceServerConfig extends ResourceServerConfigurerAdapter{

	@Override
	public void configure(HttpSecurity http) throws Exception {
		
		http.addFilterBefore(new EncodingFilter(), ChannelProcessingFilter.class);
		
		http
		.authorizeRequests()
		.antMatchers(HttpMethod.POST,"/api/captcha/verify").permitAll()
		//		"/api/sesion/autorizacion/datos").permitAll()
		//.antMatchers(HttpMethod.GET,"/api/sesion/autenticacion/entidades/{uid}").permitAll()
		.anyRequest().authenticated()
		.and().cors().configurationSource(corsConfigurationSource());
		
	}
	
	
	@Bean
	public CorsConfigurationSource corsConfigurationSource() {
		
		CorsConfiguration config = new CorsConfiguration();
		config.setAllowedOrigins(Arrays.asList("http://localhost:4200","http://172.16.38.77:9044","http://localhost:9044","http://190.216.169.212:9044",
											   "http://172.16.38.120","http://172.16.38.120:9044","http://localhost","http://192.168.32.98","http://190.216.169.247","https://190.216.169.247"));
		config.setAllowedMethods(Arrays.asList("GET", "POST", "PUT", "DELETE", "OPTIONS"));
		config.setAllowCredentials(true);
		//config.setAllowedHeaders(Arrays.asList("Content-Type", "Authorization","Access-Control-Allow-Headers"," Access-Control-Request-Headers","Access-Control-Request-Method"));
		config.setAllowedHeaders(Arrays.asList("access-control-allow-origin","Content-Type", "Authorization","Access-Control-Allow-Origin"));
		//config.setAllowedHeaders(Arrays.asList("access-control-allow-origin","Access-Control-Allow-Headers","Content-Type", "Authorization","Origin"," X-Requested-With","Accept"));
		//config.setAllowedHeaders(Arrays.asList("*"));
		
		UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
		source.registerCorsConfiguration("/**", config);
		return source;
		
	}
	
	@Bean
	public FilterRegistrationBean<CorsFilter> corsFilter(){
		FilterRegistrationBean<CorsFilter> bean = new  FilterRegistrationBean<CorsFilter>(new CorsFilter( corsConfigurationSource()));
		bean.setOrder(Ordered.HIGHEST_PRECEDENCE);
		return bean;
	}
	
}
