package pe.gob.osce.seguridad.controllers;

import java.time.Duration;
import java.time.Instant;
import java.util.HashMap;
import java.util.Map;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import pe.gob.osce.seguridad.dto.CaptchaDto;
import pe.gob.osce.seguridad.dto.Response;
import pe.gob.osce.seguridad.services.CaptchaService;
import pe.gob.osce.seguridad.utils.Constantes;

@RestController
@RequestMapping(path = "/api/captcha")
public class CaptchaController {
	
	@Autowired
	private CaptchaService captchaService;
	
	@RequestMapping(value = "/verify", method = RequestMethod.POST)
	public ResponseEntity<?> ejecutarVerificarCaptcha(@RequestBody String G_RECAPTCHA_RESPONSE) {
		Instant start = Instant.now();
		Response<Map<String, Object>> response = new Response<>();
		HttpHeaders headers = new HttpHeaders();
	    headers.setContentType(MediaType.APPLICATION_JSON);
		try {
			JSONObject result = captchaService.performRecaptchaSiteVerify(G_RECAPTCHA_RESPONSE);
			CaptchaDto captchaDto = new CaptchaDto();
			if(result!=null) {
				captchaDto.setHostname(result.getString("hostname"));
				captchaDto.setSuccess(result.getBoolean("success"));
				captchaDto.setChallenge_ts(result.getString("challenge_ts"));
			}
			Map<String, Object> res = new HashMap<>();
			res.put(Constantes.RESP_CAPTCHA, captchaDto);
			response.setResponse(res);
			response.setProcessTime(Duration.between(start, Instant.now()).toMillis());
			return new ResponseEntity<>(response, headers, HttpStatus.CREATED);
		} catch (Exception e) {
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			response.setMessage(HttpStatus.BAD_REQUEST.getReasonPhrase());
			response.setProcessTime(Duration.between(start, Instant.now()).toMillis());
			return new ResponseEntity<>(response, headers, HttpStatus.BAD_REQUEST);
		}
	}

}
