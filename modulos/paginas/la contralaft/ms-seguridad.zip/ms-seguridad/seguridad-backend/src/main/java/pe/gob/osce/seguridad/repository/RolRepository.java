package pe.gob.osce.seguridad.repository;

import java.util.List;

import pe.gob.osce.seguridad.seace.dto.RolDto;

public interface RolRepository{

	List<RolDto> obtenerRolesByIdUsuario(String uid);
	List<RolDto> obtenerRolesByIdModuloByIdUsuario(Long idModulo, String uid);
	
}
