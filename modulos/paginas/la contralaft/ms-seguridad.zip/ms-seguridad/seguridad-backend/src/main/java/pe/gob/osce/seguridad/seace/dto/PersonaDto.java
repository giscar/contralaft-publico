package pe.gob.osce.seguridad.seace.dto;

import java.util.Date;
import java.util.List;

import pe.gob.osce.seguridad.utils.DataTransferObjectUtil;


public class PersonaDto extends DataTransferObjectUtil {

	private static final long serialVersionUID = 1L;

    private Long id;

    private String tipoDocumento;

    private String nombres;

    private String apellidos;

    private String nombreCompleto;

    private String numeroDocumento;

    private String codigoCargo;

    private String numeroTelefono;

    private String numeroAnexo;

    private String numeroFax;

    private String numeroCelular;

    private String email;

    private Date fechaCreacion;

    private String usuarioCreacion;

    private Date ultimaFechaModificacion;

    private String ultimoUsuarioModificacion;

    private TipificacionPersonaDto tipificacionPersona;
    
    private List<EntidadPersonaDto> listaEntidadPersona;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTipoDocumento() {
        return tipoDocumento;
    }

    public void setTipoDocumento(String tipoDocumento) {
        this.tipoDocumento = tipoDocumento;
    }

    public String getNombres() {
        return nombres;
    }

    public void setNombres(String nombres) {
        this.nombres = nombres;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public String getNombreCompleto() {
        return nombreCompleto;
    }

    public void setNombreCompleto(String nombreCompleto) {
        this.nombreCompleto = nombreCompleto;
    }

    public String getNumeroDocumento() {
        return numeroDocumento;
    }

    public void setNumeroDocumento(String numeroDocumento) {
        this.numeroDocumento = numeroDocumento;
    }

    public String getCodigoCargo() {
        return codigoCargo;
    }

    public void setCodigoCargo(String codigoCargo) {
        this.codigoCargo = codigoCargo;
    }

    public String getNumeroTelefono() {
        return numeroTelefono;
    }

    public void setNumeroTelefono(String numeroTelefono) {
        this.numeroTelefono = numeroTelefono;
    }

    public String getNumeroAnexo() {
        return numeroAnexo;
    }

    public void setNumeroAnexo(String numeroAnexo) {
        this.numeroAnexo = numeroAnexo;
    }

    public String getNumeroFax() {
        return numeroFax;
    }

    public void setNumeroFax(String numeroFax) {
        this.numeroFax = numeroFax;
    }

    public String getNumeroCelular() {
        return numeroCelular;
    }

    public void setNumeroCelular(String numeroCelular) {
        this.numeroCelular = numeroCelular;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    @Override
    public Date getFechaCreacion() {
        return fechaCreacion;
    }

    @Override
    public void setFechaCreacion(Date fechaCreacion) {
        this.fechaCreacion = fechaCreacion;
    }

    public String getUsuarioCreacion() {
        return usuarioCreacion;
    }

    public void setUsuarioCreacion(String usuarioCreacion) {
        this.usuarioCreacion = usuarioCreacion;
    }

    public Date getUltimaFechaModificacion() {
        return ultimaFechaModificacion;
    }

    public void setUltimaFechaModificacion(Date ultimaFechaModificacion) {
        this.ultimaFechaModificacion = ultimaFechaModificacion;
    }

    public String getUltimoUsuarioModificacion() {
        return ultimoUsuarioModificacion;
    }

    public void setUltimoUsuarioModificacion(String ultimoUsuarioModificacion) {
        this.ultimoUsuarioModificacion = ultimoUsuarioModificacion;
    }

    public TipificacionPersonaDto getTipificacionPersona() {
        return tipificacionPersona;
    }
    
    public void setTipificacionPersona(TipificacionPersonaDto tipificacionPersona) {
        this.tipificacionPersona = tipificacionPersona;
    }

    public List<EntidadPersonaDto> getListaEntidadPersona() {
        return listaEntidadPersona;
    }

    public void setListaEntidadPersona(List<EntidadPersonaDto> listaEntidadPersona) {
        this.listaEntidadPersona = listaEntidadPersona;
    }
}
