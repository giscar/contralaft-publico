package pe.gob.osce.seguridad.services;

import java.util.List;

import pe.gob.osce.seguridad.dto.EntidadDto;
import pe.gob.osce.seguridad.dto.UsuarioSesionDto;
import pe.gob.osce.seguridad.seace.dto.PrivilegioDto;

public interface PrivilegioService {
	
	public List<PrivilegioDto> obtenerPrivilegios(UsuarioSesionDto usuarioDto);
	public List<String> obtenerPrivilegiosSoloAcciones(UsuarioSesionDto usuarioDto);
}
