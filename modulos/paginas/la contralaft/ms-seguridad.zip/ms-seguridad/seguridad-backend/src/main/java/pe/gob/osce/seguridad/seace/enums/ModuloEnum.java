package pe.gob.osce.seguridad.seace.enums;

import java.util.ArrayList;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public enum ModuloEnum{
	MODULO_SEACE_INTERFACE3(1L,"INTERFACES"),
	MODULO_SEACE_PORTAL3(2L,"PORTAL"),
	MODULO_SEACE_ADMINISTRACION3(3L,"ADMINISTRACION"),
	MODULO_RNP(4L,"RNP"),
	MODULO_SEACE_ACTOS_PREPARATORIOS3(5L,"ACTOS PREPARATORIOS"),
	MODULO_SEACE_CONFIGURADOR3(6L,"CONFIGURADOR"),
	MODULO_SEACE_SELECCION3(7L,"SELECCION"),	
	MODULO_SEACE_PAC3(8L,"PAC"),
	MODULO_SEACE_CUBSO3(9L,"CUBSO"),
	MODULO_SEACE_CONTRATOS3(10L,"CONTRATOS"),
	MODULO_SEACE2(100L,"SEACE V2"),
	MODULO_SEGOSCE_2001(2001L,"SISTEMA RNP"),
	MODULO_SEGOSCE_3001(3001L,"ARBITRAJE v1"),
	MODULO_SEGOSCE_3002(3002L,"SISTEMA RNAS"),		
	MODULO_SEGOSCE_11(11L,"SISTEMA DE SEGURIDAD SEGOSCE"),
	MODULO_RNP4(300L,"RNP 4"),	
	MODULO_SEACE_GIBSOM1(400L,"MANTIS");
	
	private Long key;
	private String value;
	
	private static List<ModuloEnum> list = new ArrayList<ModuloEnum>();
	private static Map<Long, ModuloEnum> lookup = new HashMap<Long, ModuloEnum>();
	
	static {
		for (ModuloEnum s : EnumSet.allOf(ModuloEnum.class)) {
			list.add(s);
			lookup.put(s.getKey(), s);
		}
	}
	private ModuloEnum(Long key, String value) {
		this.setKey(key);
		this.setValue(value);
	}
	public Long getKey() {
		return key;
	}
	public void setKey(Long key) {
		this.key = key;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}	
	public static ModuloEnum get(Long key) {
		return lookup.get(key);
	}
}
