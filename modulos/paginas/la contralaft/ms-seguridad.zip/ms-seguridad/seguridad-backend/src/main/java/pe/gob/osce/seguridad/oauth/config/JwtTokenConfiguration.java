package pe.gob.osce.seguridad.oauth.config;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.oauth2.common.DefaultOAuth2AccessToken;
import org.springframework.security.oauth2.common.OAuth2AccessToken;
import org.springframework.security.oauth2.provider.OAuth2Authentication;
import org.springframework.security.oauth2.provider.token.TokenEnhancer;
import org.springframework.stereotype.Component;

import pe.gob.osce.seguridad.seace.dto.UsuarioDto;
import pe.gob.osce.seguridad.dto.UsuarioSesionDto;
import pe.gob.osce.seguridad.jdbc.entity.Usuario;
import pe.gob.osce.seguridad.jdbc.service.IUsuarioService;
import pe.gob.osce.seguridad.ldap.dto.AttibuteUsuarioLdapDTO;
import pe.gob.osce.seguridad.ldap.dto.UsuarioLdapDTO;
import pe.gob.osce.seguridad.ldap.utils.LdapUserMapper;
import pe.gob.osce.seguridad.services.UsuarioService;

//import pe.gob.osce.seguridad.ldap.utils.CustomLdapUserDetails;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component("tokenEnhancer")
public class JwtTokenConfiguration implements TokenEnhancer {
	
	
	@Autowired
	private UsuarioService usuarioService;
	
	@Autowired
	private LdapUserMapper LdapUserMapper;

    @Override
    public OAuth2AccessToken enhance(
            OAuth2AccessToken accessToken,
            OAuth2Authentication authentication) {

    	//UsuarioLdapDTO attibuteUsuarioLdap = new UsuarioLdapDTO();
    	UsuarioSesionDto usuario= new UsuarioSesionDto();
    	//List<EntidadDTO> listaEntidades = null;
        //Usuario usuario = iUsuarioService.findByUsername(authentication.getName());
        try {
        	//attibuteUsuarioLdap=LdapUserMapper.getDetailUserLdap(authentication.getName());
        	UsuarioDto usuarioDto = usuarioService.obtenerUsuarioLogin(authentication.getName());
        	//if(attibuteUsuarioLdap!=null) {
        	if(usuarioDto!=null) {
        		usuario.setUid(authentication.getName().toString());
        		usuario.setNombreSesion(usuarioDto.getPersona().getNombreCompleto());
        		usuario.setEmail(usuarioDto.getPersona().getEmail());
        		//listaEntidades=iUsuarioService.getListaEntidadesByOID(authentication.getName());
        	}        	
		} catch (Exception e) {
			// TODO: handle exception
		}
        
    	Map<String, Object> additionalInfo = new HashMap<>();
        //CustomLdapUserDetails principal = (CustomLdapUserDetails) authentication.getPrincipal();
        //additionalInfo.put("user", principal.getDetails());
    	additionalInfo.put("usuario", usuario);
    	//additionalInfo.put("listaEntidades", listaEntidades);    	
        //additionalInfo.put("nombre_usuario", usuario.getIdUsuario() + ':' +  usuario.getUsername());

       ((DefaultOAuth2AccessToken) accessToken).setAdditionalInformation(additionalInfo);
        return accessToken;
    }
}