package pe.gob.osce.seguridad.jdbc.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import pe.gob.osce.seguridad.jdbc.entity.Usuario;
import pe.gob.osce.seguridad.jdbc.repository.UsuarioRepository;
import pe.gob.osce.seguridad.dto.EntidadDto;

@Service
@Transactional(readOnly = true)
public class UsuarioService implements IUsuarioService,UserDetailsService{
	
	private Logger logger = LoggerFactory.getLogger(UsuarioService.class);

	@Autowired
	private UsuarioRepository usuarioRepository;
	
	@Override
	@Transactional(readOnly=true)
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
	
		Usuario usuario= usuarioRepository.findByUsername(username);
		List<GrantedAuthority> roles = usuario.getRoles()
				.stream()
				.map(rol->new SimpleGrantedAuthority(rol.getNombreRol()))
				.collect(Collectors.toList());
		
		return new User(usuario.getUsername(), usuario.getPassword(), true, true, true, true, roles);
	}

	@Override
	@Transactional(readOnly=true)
	public Usuario findByUsername(String username) {
		return usuarioRepository.findByUsername(username);
	}

	@Override
	@Transactional(readOnly=true)
	public List<EntidadDto> getListaEntidadesByOID(String username) {
		
		List<Object[]> listaEntidades = usuarioRepository.buscarEntidadesxOID(username);
		List<EntidadDto> listaEntidadesDTO= new ArrayList<EntidadDto>();
		Object[] objSelect = new Object[] { 0, "Seleccionar" };
		
        if (listaEntidades != null && listaEntidades.size() > 0) {
        	listaEntidades.add(objSelect);
        	Collections.sort(listaEntidades, new Comparator<Object[]>() {
				@Override
				public int compare(Object[] o1, Object[] o2) {
					String nombreEntidad1 = (String) o1[1];
					String nombreEntidad2 = (String) o2[1];
					return nombreEntidad1.compareTo(nombreEntidad2);
				}
			});
            
        	for (Object[] obj : listaEntidades) {
        		
        		EntidadDto entidadDTO= new EntidadDto();
        		entidadDTO.setIdEntidad(obj[0].toString());
        		entidadDTO.setNombreEntidad(obj[1].toString());
        		listaEntidadesDTO.add(entidadDTO);
                //listaEntidad.add(new SelectItem(Long.valueOf(obj[0].toString()), String.valueOf(obj[1])));
        		
            }
           
        }
        
		return listaEntidadesDTO;
	}
        

}
