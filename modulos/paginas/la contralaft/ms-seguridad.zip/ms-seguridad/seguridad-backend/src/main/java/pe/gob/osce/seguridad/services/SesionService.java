package pe.gob.osce.seguridad.services;

import java.util.List;

import pe.gob.osce.seguridad.dto.EntidadDto;
import pe.gob.osce.seguridad.jdbc.entity.Usuario;

public interface SesionService {
	
	//public Usuario findByUsername(String username);
	
	public List<EntidadDto> getListaEntidadesByOID(String username);
}
