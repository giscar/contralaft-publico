package pe.gob.osce.seguridad.seace.enums;
import java.util.ArrayList;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;


public enum RolType {
	
	FUNCIONARIO_USUARIO_DE_CONTROL_Y_FISCALIZACION(15L, "FUNCIONARIO USUARIO DE CONTROL Y FISCALIZACION"),
	ACCESO_A_CONTRATOS_OSCE(8327L, "ACCESO A CONTRATOS - OSCE"),
	USUARIO_PLATAFORMA_CONTRATOS(8328L, "USUARIO PLATAFORMA CONTRATOS");

	private static final List<RolType> list = new ArrayList<RolType>();

	private static final Map<Long, RolType> lookup = new HashMap<Long, RolType>();

	static {
		for (RolType s : EnumSet.allOf(RolType.class)) {
			list.add(s);
			lookup.put(s.getKey(), s);
		}

	}
	
	private Long key;
	
	private String value;

	private RolType(Long key, String value) {
		this.key = key;
		this.value = value;
	}

	public Long getKey() {
		return key;
	}

	public String getValue() {
		return value;
	}

	public String getDescription(Locale locale) {
		return this.getValue();
	}

	public static RolType get(String key) {
		return lookup.get(key);
	}
}
