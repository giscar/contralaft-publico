package pe.gob.osce.seguridad.repository;

import java.util.List;

import pe.gob.osce.seguridad.seace.dto.PrivilegioDto;

public interface PrivilegioRepository{

	List<PrivilegioDto> obtenerPrivilegiosByUsuario(Long idModulo, Long idRol, Long idOrganismo, String uid);
	List<String> obtenerPrivilegiosByUsuarioSoloAcciones(Long idModulo, Long idRol, Long idOrganismo, String uid);
	List<String> obtenerPrivilegiosByUsuarioSoloAccionesTodasEntidades(Long idModulo, String uid);
	
}
