package pe.gob.osce.seguridad.seace.dto;

import java.util.Date;
import java.util.List;

import pe.gob.osce.seguridad.utils.DataTransferObjectUtil;



public class PerfilRolDto extends DataTransferObjectUtil {


	private static final long serialVersionUID = 1L;

    protected PerfilRolPKDto perfilRolPK;
    
    private Date fechaCreacion;
   
    private String usuarioCreacion;
    
    private Date ultimaFechaModificacion;
   
    private String ultimoUsuarioModificacion;
  
    private String estado;
  
    private RolDto rol = new RolDto();
  
    private PerfilDto perfil;
 
    private List<UsuarioRolDto> listaUsuarioRol;

    public PerfilRolPKDto getPerfilRolPK() {
        return perfilRolPK;
    }

    public void setPerfilRolPK(PerfilRolPKDto perfilRolPK) {
        this.perfilRolPK = perfilRolPK;
    }

    @Override
    public Date getFechaCreacion() {
        return fechaCreacion;
    }

    @Override
    public void setFechaCreacion(Date fechaCreacion) {
        this.fechaCreacion = fechaCreacion;
    }

    public String getUsuarioCreacion() {
        return usuarioCreacion;
    }

    public void setUsuarioCreacion(String usuarioCreacion) {
        this.usuarioCreacion = usuarioCreacion;
    }

    public Date getUltimaFechaModificacion() {
        return ultimaFechaModificacion;
    }

    public void setUltimaFechaModificacion(Date ultimaFechaModificacion) {
        this.ultimaFechaModificacion = ultimaFechaModificacion;
    }

    public String getUltimoUsuarioModificacion() {
        return ultimoUsuarioModificacion;
    }

    public void setUltimoUsuarioModificacion(String ultimoUsuarioModificacion) {
        this.ultimoUsuarioModificacion = ultimoUsuarioModificacion;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public RolDto getRol() {
        return rol;
    }

    public void setRol(RolDto rol) {
        this.rol = rol;
    }

    public PerfilDto getPerfil() {
        return perfil;
    }
    
    public void setPerfil(PerfilDto perfil) {
        this.perfil = perfil;
    }

    public List<UsuarioRolDto> getListaUsuarioRol() {
        return listaUsuarioRol;
    }
    
    public void setListaUsuarioRol(List<UsuarioRolDto> listaUsuarioRol) {
        this.listaUsuarioRol = listaUsuarioRol;
    }
}
