package pe.gob.osce.seguridad.services.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import pe.gob.osce.seguridad.dto.EntidadDto;
import pe.gob.osce.seguridad.repository.EntidadRepository;
import pe.gob.osce.seguridad.seace.dto.RolDto;
import pe.gob.osce.seguridad.seace.enums.RolType;
import pe.gob.osce.seguridad.services.EntidadService;
import pe.gob.osce.seguridad.services.RolService;

@Service
@Transactional(readOnly = true)
public class EntidadServiceImpl implements EntidadService{
	
	private Logger logger = LoggerFactory.getLogger(EntidadServiceImpl.class);

	@Autowired
	private EntidadRepository entidadRepository;
	
	@Autowired
	private RolService rolService;


	@Override
	@Transactional(readOnly=true)
	public List<EntidadDto> getListaEntidadesByOID(String username) {
		
		boolean tienePermisosTodasEntidades = false;
		List<Object[]> listaEntidades = null;
		List<RolDto> listaRoles = rolService.obtenerRolesByIdUsuario(username);
		if(listaRoles!=null && !listaRoles.isEmpty()) {
			for(RolDto rol: listaRoles) {
				if(rol.getId().equals(RolType.FUNCIONARIO_USUARIO_DE_CONTROL_Y_FISCALIZACION.getKey()) ||
						rol.getId().equals(RolType.ACCESO_A_CONTRATOS_OSCE.getKey()) ||
						rol.getId().equals(RolType.USUARIO_PLATAFORMA_CONTRATOS.getKey())
						) {
					tienePermisosTodasEntidades=true;
				}
			}
		}
		
		if(tienePermisosTodasEntidades) {
			listaEntidades=entidadRepository.obtenerTodasEntidades();
		}else {
			listaEntidades=entidadRepository.buscarEntidadesxOID(username);
		}
						
		List<EntidadDto> listaEntidadesDTO= new ArrayList<EntidadDto>();
		//Object[] objSelect = new Object[] { 0, "Seleccionar" };
		try {
			
			if (listaEntidades != null && listaEntidades.size() > 0) {
	        	Collections.sort(listaEntidades, new Comparator<Object[]>() {
					@Override
					public int compare(Object[] o1, Object[] o2) {
						String nombreEntidad1 = (String) o1[1];
						String nombreEntidad2 = (String) o2[1];
						return nombreEntidad1.compareTo(nombreEntidad2);
					}
				});
	            
	        	for (Object[] obj : listaEntidades) {
	        		
	        		EntidadDto entidadDTO= new EntidadDto();
	        		entidadDTO.setIdEntidad(obj[0].toString());
	        		entidadDTO.setNombreEntidad(obj[1].toString());
	        		listaEntidadesDTO.add(entidadDTO);
	                //listaEntidad.add(new SelectItem(Long.valueOf(obj[0].toString()), String.valueOf(obj[1])));
	        		
	            }
	           
	        }
		} catch (Exception e) {
			logger.error(e.getMessage());
		}

		return listaEntidadesDTO;
	}
        

}
