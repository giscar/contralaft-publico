package pe.gob.osce.seguridad.jdbc.repository;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import pe.gob.osce.seguridad.jdbc.entity.Usuario;

public interface UsuarioRepository extends CrudRepository<Usuario, Long> {
	
	public Usuario findByUsername(String username);
	
	@Query("Select u from Usuario u where u.username=?1 and u.estadoUsuario=1 and u.estadoRegistro=1")
	public Usuario findByUsername2(String username);
	
	
	@Query(value="SELECT ORG.N_ID_ORGAN AS CODIGO, ORG.C_NOMORG AS NOMBRE\r\n" + 
			"FROM ADM.DET_ADM_USU_ORG USUORG\r\n" + 
			"INNER JOIN ADM.TBL_ADM_ORG ORG ON USUORG.N_ID_ORGAN = ORG.N_ID_ORGAN\r\n" + 
			"INNER JOIN ADM.TBL_ADM_USU USU ON USUORG.N_ID_PERS = USU.N_ID_PERS\r\n" + 
			"WHERE USUORG.C_ESTADO = 'ACTIV' \r\n" + 
			"AND USU.C_CODOID =?1 \r\n" + 
			"AND ORG.N_ID_TIPORG =1",nativeQuery = true)
	public List<Object[]> buscarEntidadesxOID(String oid);
	
}
