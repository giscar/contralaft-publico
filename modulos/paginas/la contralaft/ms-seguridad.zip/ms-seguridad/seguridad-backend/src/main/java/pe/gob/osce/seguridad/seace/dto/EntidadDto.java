package pe.gob.osce.seguridad.seace.dto;

import java.util.Date;
import java.util.List;


public class EntidadDto extends OrganismoDto {

	private static final long serialVersionUID = 1L;

	private String numeroCue;

    private String codigoSiaf;

    private String unidadEjecutora;

    private String sector;

    private Integer indicadorTieneUnidadOperativa;

    private Integer indicadorEsUnidadOperativa;

    private String actividad;

    private String tipoGobiernoCentral;

    private String tipoOrganismoPublicoEspecializado;

    private String tipoInstanciaDescentralizada;

    private String tipoGobiernoLocal;

    private String tipoGobiernoRegional;

    private String categoriaFonafe;

    private Integer indicadorTlc;

    private Integer indicadorConvocarProcesosElectronicos;

    private Integer indicadorProcesoSeleccionExtemporaneo;

    private Integer indicadorSecretoMilitar;

    private Integer indicadorTransfiereContratosSiaf;

    private Integer indicadorFuncionControlFiscalizacion;

    private boolean hidden;

    private String estadoActivacion;
 
    private String pliego;

    private Long totalPersonal;

    private Date fechaCreacion;

    private String usuarioCreacion;

    private Date ultimaFechaModificacion;

    private String ultimoUsuarioModificacion;

    private Date ultimaFechaActivacion;

    private String ultimoUsuarioActivacion;

    private Date ultimaFechaDesactivacion;

    private String ultimoUsuarioDesactivacion;

    private String justificacion;

    private String nroTramite;

    private List<EntidadPersonaDto> listaEntidadPersona;

    private Long idAuditoriaUsuario;

    public String getNumeroCue() {
        return numeroCue;
    }

    public void setNumeroCue(String numeroCue) {
        this.numeroCue = numeroCue;
    }

    public String getCodigoSiaf() {
        return codigoSiaf;
    }

    public void setCodigoSiaf(String codigoSiaf) {
        this.codigoSiaf = codigoSiaf;
    }

    public String getUnidadEjecutora() {
		return unidadEjecutora;
	}

	public void setUnidadEjecutora(String unidadEjecutora) {
		this.unidadEjecutora = unidadEjecutora;
	}

    public String getSector() {
        return sector;
    }

    public void setSector(String sector) {
        this.sector = sector;
    }

    public Integer getIndicadorTieneUnidadOperativa() {
        return indicadorTieneUnidadOperativa;
    }

    public void setIndicadorTieneUnidadOperativa(Integer indicadorTieneUnidadOperativa) {
        this.indicadorTieneUnidadOperativa = indicadorTieneUnidadOperativa;
    }

    public Integer getIndicadorEsUnidadOperativa() {
        return indicadorEsUnidadOperativa;
    }

    public void setIndicadorEsUnidadOperativa(Integer indicadorEsUnidadOperativa) {
        this.indicadorEsUnidadOperativa = indicadorEsUnidadOperativa;
    }

    public String getActividad() {
        return actividad;
    }

    public void setActividad(String actividad) {
        this.actividad = actividad;
    }

    public String getTipoGobiernoCentral() {
        return tipoGobiernoCentral;
    }

    public void setTipoGobiernoCentral(String tipoGobiernoCentral) {
        this.tipoGobiernoCentral = tipoGobiernoCentral;
    }

    public String getTipoOrganismoPublicoEspecializado() {
        return tipoOrganismoPublicoEspecializado;
    }

    public void setTipoOrganismoPublicoEspecializado(
            String tipoOrganismoPublicoEspecializado) {
        this.tipoOrganismoPublicoEspecializado = tipoOrganismoPublicoEspecializado;
    }

    public String getTipoInstanciaDescentralizada() {
        return tipoInstanciaDescentralizada;
    }

    public void setTipoInstanciaDescentralizada(String tipoInstanciaDescentralizada) {
        this.tipoInstanciaDescentralizada = tipoInstanciaDescentralizada;
    }

    public String getTipoGobiernoLocal() {
        return tipoGobiernoLocal;
    }

    public void setTipoGobiernoLocal(String tipoGobiernoLocal) {
        this.tipoGobiernoLocal = tipoGobiernoLocal;
    }

    public String getTipoGobiernoRegional() {
        return tipoGobiernoRegional;
    }

    public void setTipoGobiernoRegional(String tipoGobiernoRegional) {
        this.tipoGobiernoRegional = tipoGobiernoRegional;
    }

    public String getCategoriaFonafe() {
        return categoriaFonafe;
    }

    public void setCategoriaFonafe(String categoriaFonafe) {
        this.categoriaFonafe = categoriaFonafe;
    }

    public Integer getIndicadorTlc() {
        return indicadorTlc;
    }

    public void setIndicadorTlc(Integer indicadorTlc) {
        this.indicadorTlc = indicadorTlc;
    }

    public Integer getIndicadorConvocarProcesosElectronicos() {
        return indicadorConvocarProcesosElectronicos;
    }

    public void setIndicadorConvocarProcesosElectronicos(
            Integer indicadorConvocarProcesosElectronicos) {
        this.indicadorConvocarProcesosElectronicos = indicadorConvocarProcesosElectronicos;
    }

    public Integer getIndicadorProcesoSeleccionExtemporaneo() {
        return indicadorProcesoSeleccionExtemporaneo;
    }

    public void setIndicadorProcesoSeleccionExtemporaneo(
            Integer indicadorProcesoSeleccionExtemporaneo) {
        this.indicadorProcesoSeleccionExtemporaneo = indicadorProcesoSeleccionExtemporaneo;
    }

    public Integer getIndicadorSecretoMilitar() {
		return indicadorSecretoMilitar;
	}

	public void setIndicadorSecretoMilitar(Integer indicadorSecretoMilitar) {
		this.indicadorSecretoMilitar = indicadorSecretoMilitar;
	}

    public Integer getIndicadorTransfiereContratosSiaf() {
        return indicadorTransfiereContratosSiaf;
    }

    public void setIndicadorTransfiereContratosSiaf(
            Integer indicadorTransfiereContratosSiaf) {
        this.indicadorTransfiereContratosSiaf = indicadorTransfiereContratosSiaf;
    }

    public Integer getIndicadorFuncionControlFiscalizacion() {
        return indicadorFuncionControlFiscalizacion;
    }

    public void setIndicadorFuncionControlFiscalizacion(
            Integer indicadorFuncionControlFiscalizacion) {
        this.indicadorFuncionControlFiscalizacion = indicadorFuncionControlFiscalizacion;
    }

    public boolean getHidden() {
        return hidden;
    }

    public void setHidden(boolean hidden) {
        this.hidden = hidden;
    }

    public String getEstadoActivacion() {
        return estadoActivacion;
    }

    public void setEstadoActivacion(String estadoActivacion) {
        this.estadoActivacion = estadoActivacion;
    }

    public String getPliego() {
        return pliego;
    }

    public void setPliego(String pliego) {
        this.pliego = pliego;
    }

    public Long getTotalPersonal() {
        return totalPersonal;
    }

    public void setTotalPersonal(Long totalPersonal) {
        this.totalPersonal = totalPersonal;
    }

    @Override
    public Date getFechaCreacion() {
        return fechaCreacion;
    }

    @Override
    public void setFechaCreacion(Date fechaCreacion) {
        this.fechaCreacion = fechaCreacion;
    }

    @Override
    public String getUsuarioCreacion() {
        return usuarioCreacion;
    }

    @Override
    public void setUsuarioCreacion(String usuarioCreacion) {
        this.usuarioCreacion = usuarioCreacion;
    }

    @Override
    public Date getUltimaFechaModificacion() {
        return ultimaFechaModificacion;
    }

    @Override
    public void setUltimaFechaModificacion(Date ultimaFechaModificacion) {
        this.ultimaFechaModificacion = ultimaFechaModificacion;
    }

    @Override
    public String getUltimoUsuarioModificacion() {
        return ultimoUsuarioModificacion;
    }

    @Override
    public void setUltimoUsuarioModificacion(String ultimoUsuarioModificacion) {
        this.ultimoUsuarioModificacion = ultimoUsuarioModificacion;
    }

    public Date getUltimaFechaActivacion() {
        return ultimaFechaActivacion;
    }

    public void setUltimaFechaActivacion(Date ultimaFechaActivacion) {
        this.ultimaFechaActivacion = ultimaFechaActivacion;
    }

    public String getUltimoUsuarioActivacion() {
        return ultimoUsuarioActivacion;
    }

    public void setUltimoUsuarioActivacion(String ultimoUsuarioActivacion) {
        this.ultimoUsuarioActivacion = ultimoUsuarioActivacion;
    }

    public Date getUltimaFechaDesactivacion() {
        return ultimaFechaDesactivacion;
    }

    public void setUltimaFechaDesactivacion(Date ultimaFechaDesactivacion) {
        this.ultimaFechaDesactivacion = ultimaFechaDesactivacion;
    }

    public String getUltimoUsuarioDesactivacion() {
        return ultimoUsuarioDesactivacion;
    }

    public void setUltimoUsuarioDesactivacion(String ultimoUsuarioDesactivacion) {
        this.ultimoUsuarioDesactivacion = ultimoUsuarioDesactivacion;
    }

	public String getJustificacion() {
		return justificacion;
	}

	public void setJustificacion(String justificacion) {
		this.justificacion = justificacion;
	}

	public String getNroTramite() {
		return nroTramite;
	}

	public void setNroTramite(String nroTramite) {
		this.nroTramite = nroTramite;
	}

    public List<EntidadPersonaDto> getListaEntidadPersona() {
        return listaEntidadPersona;
    }

    public void setListaEntidadPersona(List<EntidadPersonaDto> listaEntidadPersona) {
        this.listaEntidadPersona = listaEntidadPersona;
    }

    public Long getIdAuditoriaUsuario() {
		return idAuditoriaUsuario;
	}

    public void setIdAuditoriaUsuario(Long idAuditoriaUsuario) {
		this.idAuditoriaUsuario = idAuditoriaUsuario;
	}
	
}
