package pe.gob.osce.seguridad.repository;


import pe.gob.osce.seguridad.seace.dto.UsuarioDto;

public interface UsuarioRepository{

	UsuarioDto obtenerEstadoUsuarioByUserName(String userName);
	UsuarioDto obtenerUsuarioByUserName(String userName);
	boolean actualizarEstadoUsuario(String userName, String estado);
	
}
