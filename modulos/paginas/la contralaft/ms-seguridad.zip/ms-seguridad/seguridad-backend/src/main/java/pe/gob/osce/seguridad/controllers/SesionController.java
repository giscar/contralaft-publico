package pe.gob.osce.seguridad.controllers;

import java.time.Duration;
import java.time.Instant;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import pe.gob.osce.seguridad.dto.CaptchaDto;
import pe.gob.osce.seguridad.dto.EntidadDto;
import pe.gob.osce.seguridad.dto.UsuarioSesionDto;
import pe.gob.osce.seguridad.seace.dto.PrivilegioDto;
import pe.gob.osce.seguridad.dto.Response;
import pe.gob.osce.seguridad.services.CaptchaService;
import pe.gob.osce.seguridad.services.EntidadService;
import pe.gob.osce.seguridad.services.PrivilegioService;
import pe.gob.osce.seguridad.services.SesionService;
import pe.gob.osce.seguridad.utils.Constantes;

@RestController
@RequestMapping(path = "/api/sesion")
public class SesionController {
	
	@Autowired
	private EntidadService entidadService;
	
	@Autowired
	private PrivilegioService privilegioService;
	
	@RequestMapping(value = "/autenticacion/entidades/{uid}", method = RequestMethod.GET)
	public ResponseEntity<?> obtenerEntidadesByUsuario(@PathVariable("uid") final String uid) {
		Instant start = Instant.now();
		Response<Map<String, Object>> response = new Response<>();
		HttpHeaders headers = new HttpHeaders();
	    headers.setContentType(MediaType.APPLICATION_JSON);
		try {
			List<EntidadDto> result = entidadService.getListaEntidadesByOID(uid);			
			Map<String, Object> res = new HashMap<>();
			res.put(Constantes.RESP_ENTIDADES, result);
			response.setResponse(res);
			response.setProcessTime(Duration.between(start, Instant.now()).toMillis());
			return new ResponseEntity<>(response, headers, HttpStatus.CREATED);
		} catch (Exception e) {
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			response.setMessage(HttpStatus.BAD_REQUEST.getReasonPhrase());
			response.setProcessTime(Duration.between(start, Instant.now()).toMillis());
			return new ResponseEntity<>(response, headers, HttpStatus.BAD_REQUEST);
		}
	}
	@RequestMapping(value = "/autorizacion/datos", method = RequestMethod.POST)
	public ResponseEntity<?> obtenerDatosAutorizacion(@RequestBody UsuarioSesionDto usuarioDto) {
		Instant start = Instant.now();
		Response<Map<String, Object>> response = new Response<>();
		HttpHeaders headers = new HttpHeaders();
	    headers.setContentType(MediaType.APPLICATION_JSON);
		try {
			List<String> result = privilegioService.obtenerPrivilegiosSoloAcciones(usuarioDto);			
			Map<String, Object> res = new HashMap<>();
			res.put(Constantes.RESP_PRIVILEGIOS, result);
			response.setResponse(res);
			response.setProcessTime(Duration.between(start, Instant.now()).toMillis());
			return new ResponseEntity<>(response, headers, HttpStatus.CREATED);
		} catch (Exception e) {
			response.setStatus(HttpStatus.BAD_REQUEST.value());
			response.setMessage(HttpStatus.BAD_REQUEST.getReasonPhrase());
			response.setProcessTime(Duration.between(start, Instant.now()).toMillis());
			return new ResponseEntity<>(response, headers, HttpStatus.BAD_REQUEST);
		}
	}

}
