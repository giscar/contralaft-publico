package pe.gob.osce.seguridad.seace.dto;

import java.util.Date;
import java.util.List;

import pe.gob.osce.seguridad.seace.enums.EstadoState;
import pe.gob.osce.seguridad.utils.DataTransferObjectUtil;




public class OrganismoDto extends DataTransferObjectUtil {

	private static final long serialVersionUID = 1L;

	private Long id;

    private String nombreOrganismo;

    private String tipoDocumento;

    private String numeroDocumento;

    private String razonSocial;

    private String direccionFiscal;

    private String sigla;

    private String numeroTelefono;

    private String paginaWeb;

    private String codigoTipoVia;

    private String otraVia;

    private String nombreVia;

    private String numeroVia;

    private String urbanizacion;

    private String codigoPostal;

    private int indicadorSunat;

    private String estado;

    private Date fechaCreacion;

    private String usuarioCreacion;

    private Date ultimaFechaModificacion;

    private String ultimoUsuarioModificacion;

    private UbigeoDto ubigeo;

    private TipificacionOrganismoDto tipificacionOrganismo;

    private List<UsuarioOrganismoDto> listaUsuarioOrganismo;

    private List<OrganismoPerfilDto> listaOrganismoPerfil;

    private EstadoState estadoOrganismo;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getNombreOrganismo() {
        return nombreOrganismo;
    }

    public void setNombreOrganismo(String nombreOrganismo) {
        this.nombreOrganismo = nombreOrganismo;
    }

    public String getTipoDocumento() {
        return tipoDocumento;
    }

    public void setTipoDocumento(String tipoDocumento) {
        this.tipoDocumento = tipoDocumento;
    }

    public String getNumeroDocumento() {
        return numeroDocumento;
    }

    public void setNumeroDocumento(String numeroDocumento) {
        this.numeroDocumento = numeroDocumento;
    }

    public String getRazonSocial() {
        return razonSocial;
    }

    public void setRazonSocial(String razonSocial) {
        this.razonSocial = razonSocial;
    }

    public String getDireccionFiscal() {
        return direccionFiscal;
    }

    public void setDireccionFiscal(String direccionFiscal) {
        this.direccionFiscal = direccionFiscal;
    }

    public String getSigla() {
        return sigla;
    }

    public void setSigla(String sigla) {
        this.sigla = sigla;
    }

    public String getNumeroTelefono() {
        return numeroTelefono;
    }

    public void setNumeroTelefono(String numeroTelefono) {
        this.numeroTelefono = numeroTelefono;
    }

    public String getPaginaWeb() {
        return paginaWeb;
    }

    public void setPaginaWeb(String paginaWeb) {
        this.paginaWeb = paginaWeb;
    }

    public String getCodigoTipoVia() {
        return codigoTipoVia;
    }

    public void setCodigoTipoVia(String codigoTipoVia) {
        this.codigoTipoVia = codigoTipoVia;
    }

    public String getOtraVia() {
        return otraVia;
    }

    public void setOtraVia(String otraVia) {
        this.otraVia = otraVia;
    }

    public String getNombreVia() {
        return nombreVia;
    }

    public void setNombreVia(String nombreVia) {
        this.nombreVia = nombreVia;
    }

    public String getNumeroVia() {
        return numeroVia;
    }

    public void setNumeroVia(String numeroVia) {
        this.numeroVia = numeroVia;
    }

    public String getUrbanizacion() {
        return urbanizacion;
    }

    public void setUrbanizacion(String urbanizacion) {
        this.urbanizacion = urbanizacion;
    }

    public String getCodigoPostal() {
        return codigoPostal;
    }

    public void setCodigoPostal(String codigoPostal) {
        this.codigoPostal = codigoPostal;
    }

    public int getIndicadorSunat() {
        return indicadorSunat;
    }

    public void setIndicadorSunat(int indicadorSunat) {
        this.indicadorSunat = indicadorSunat;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estadoOrganismo = EstadoState.get(estado);
        this.estado = estado;
    }

    @Override
    public Date getFechaCreacion() {
        return fechaCreacion;
    }

    @Override
    public void setFechaCreacion(Date fechaCreacion) {
        this.fechaCreacion = fechaCreacion;
    }

    public String getUsuarioCreacion() {
        return usuarioCreacion;
    }

    public void setUsuarioCreacion(String usuarioCreacion) {
        this.usuarioCreacion = usuarioCreacion;
    }

    public Date getUltimaFechaModificacion() {
        return ultimaFechaModificacion;
    }

    public void setUltimaFechaModificacion(Date ultimaFechaModificacion) {
        this.ultimaFechaModificacion = ultimaFechaModificacion;
    }

    public String getUltimoUsuarioModificacion() {
        return ultimoUsuarioModificacion;
    }

    public void setUltimoUsuarioModificacion(String ultimoUsuarioModificacion) {
        this.ultimoUsuarioModificacion = ultimoUsuarioModificacion;
    }

    public UbigeoDto getUbigeo() {
        return ubigeo;
    }

    public void setUbigeo(UbigeoDto ubigeo) {
        this.ubigeo = ubigeo;
    }

    public TipificacionOrganismoDto getTipificacionOrganismo() {
        return tipificacionOrganismo;
    }

    public void setTipificacionOrganismo(TipificacionOrganismoDto tipificacionOrganismo) {
        this.tipificacionOrganismo = tipificacionOrganismo;
    }

    public List<UsuarioOrganismoDto> getListaUsuarioOrganismo() {
        return listaUsuarioOrganismo;
    }

    public void setListaUsuarioOrganismo(
            List<UsuarioOrganismoDto> listaUsuarioOrganismo) {
        this.listaUsuarioOrganismo = listaUsuarioOrganismo;
    }

    public EstadoState getEstadoOrganismo() {
        return estadoOrganismo;
    }

    public void setEstadoOrganismo(EstadoState estadoOrganismo) {
        this.estadoOrganismo = estadoOrganismo;
    }

    public List<OrganismoPerfilDto> getListaOrganismoPerfil() {
        return listaOrganismoPerfil;
    }

    public void setListaOrganismoPerfil(
            List<OrganismoPerfilDto> listaOrganismoPerfil) {
        this.listaOrganismoPerfil = listaOrganismoPerfil;
    }
}
