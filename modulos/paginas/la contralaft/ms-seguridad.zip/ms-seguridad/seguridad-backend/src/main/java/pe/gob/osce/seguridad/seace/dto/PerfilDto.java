package pe.gob.osce.seguridad.seace.dto;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import pe.gob.osce.seguridad.seace.enums.EstadoState;
import pe.gob.osce.seguridad.utils.DataTransferObjectUtil;

public class PerfilDto extends DataTransferObjectUtil {

	private static final long serialVersionUID = 1L;

	private Long id;
	
	private String codigoOID;

	private String nombre;

	private String descripcion;

	private String estado;
	
	private Date fechaCreacion;

	private String usuarioCreacion;

	private Date ultimaFechaModificacion;

	private String ultimoUsuarioModificacion;

	private Date ultimaFechaActivacion;

	private String ultimoUsuarioActivacion;

	private Date ultimaFechaDesactivacion;

	private String ultimoUsuarioDesactivacion;

	private List<PerfilRolDto> listaPerfilRol = new ArrayList<PerfilRolDto>();

	private List<OrganismoPerfilDto> listaOrganismoPerfil;

	private EstadoState estadoPerfil;

	private boolean hidden;

	private String accion;

	private Date fechaAccion;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getCodigoOID() {
		return codigoOID;
	}

	public void setCodigoOID(String codigoOID) {
		this.codigoOID = codigoOID;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public String getEstado() {
		return estado;
	}

	public void setEstado(String estado) {
		this.estadoPerfil = EstadoState.get(estado);
		this.estado = estado;
	}

	public boolean getHidden() {
		return hidden;
	}

	public void setHidden(boolean hidden) {
		this.hidden = hidden;
	}

    @Override
	public Date getFechaCreacion() {
		return fechaCreacion;
	}

    @Override
	public void setFechaCreacion(Date fechaCreacion) {
		this.fechaCreacion = fechaCreacion;
	}

	public String getUsuarioCreacion() {
		return usuarioCreacion;
	}

	public void setUsuarioCreacion(String usuarioCreacion) {
		this.usuarioCreacion = usuarioCreacion;
	}

	public Date getUltimaFechaModificacion() {
		return ultimaFechaModificacion;
	}

	public void setUltimaFechaModificacion(Date ultimaFechaModificacion) {
		this.ultimaFechaModificacion = ultimaFechaModificacion;
	}

	public String getUltimoUsuarioModificacion() {
		return ultimoUsuarioModificacion;
	}

	public void setUltimoUsuarioModificacion(String ultimoUsuarioModificacion) {
		this.ultimoUsuarioModificacion = ultimoUsuarioModificacion;
	}

	public Date getUltimaFechaActivacion() {
		return ultimaFechaActivacion;
	}

	public void setUltimaFechaActivacion(Date ultimaFechaActivacion) {
		this.ultimaFechaActivacion = ultimaFechaActivacion;
	}

	public String getUltimoUsuarioActivacion() {
		return ultimoUsuarioActivacion;
	}

	public void setUltimoUsuarioActivacion(String ultimoUsuarioActivacion) {
		this.ultimoUsuarioActivacion = ultimoUsuarioActivacion;
	}

	public Date getUltimaFechaDesactivacion() {
		return ultimaFechaDesactivacion;
	}

	public void setUltimaFechaDesactivacion(Date ultimaFechaDesactivacion) {
		this.ultimaFechaDesactivacion = ultimaFechaDesactivacion;
	}

	public String getUltimoUsuarioDesactivacion() {
		return ultimoUsuarioDesactivacion;
	}

	public void setUltimoUsuarioDesactivacion(String ultimoUsuarioDesactivacion) {
		this.ultimoUsuarioDesactivacion = ultimoUsuarioDesactivacion;
	}

	public List<PerfilRolDto> getListaPerfilRol() {
		return listaPerfilRol;
	}

	public void setListaPerfilRol(List<PerfilRolDto> listaPerfilRol) {
		this.listaPerfilRol = listaPerfilRol;
	}

	public EstadoState getEstadoPerfil() {
		return estadoPerfil;
	}

	public void setEstadoPerfil(EstadoState estadoPerfil) {
		this.estadoPerfil = estadoPerfil;
	}

	public List<OrganismoPerfilDto> getListaOrganismoPerfil() {
		return listaOrganismoPerfil;
	}

	public void setListaOrganismoPerfil(
			List<OrganismoPerfilDto> listaOrganismoPerfil) {
		this.listaOrganismoPerfil = listaOrganismoPerfil;
	}

	public String getAccion() {
		return accion;
	}

    public void setAccion(String accion) {
		this.accion = accion;
	}

	public Date getFechaAccion() {
		return fechaAccion;
	}

	public void setFechaAccion(Date fechaAccion) {
		this.fechaAccion = fechaAccion;
	}
	
}