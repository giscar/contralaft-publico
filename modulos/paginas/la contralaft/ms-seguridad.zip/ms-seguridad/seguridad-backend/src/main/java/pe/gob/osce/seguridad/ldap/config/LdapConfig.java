package pe.gob.osce.seguridad.ldap.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.ldap.core.LdapTemplate;
import org.springframework.ldap.core.support.LdapContextSource;

import pe.gob.osce.seguridad.ldap.utils.UsuarioLDAPUtil;

@Configuration
public class LdapConfig {
	public LdapContextSource contextSource() {
		final LdapContextSource	contextSource = new LdapContextSource();
		
		contextSource.setUrl(UsuarioLDAPUtil.URL + UsuarioLDAPUtil.BASE_DN);
		contextSource.setUserDn(UsuarioLDAPUtil.loginDN);
		contextSource.setPassword(UsuarioLDAPUtil.password);
		contextSource.afterPropertiesSet();
		
		return contextSource;

	}
	
	@Bean
	public LdapTemplate ldapTemplate() {
		return new LdapTemplate(contextSource());
	}
}
