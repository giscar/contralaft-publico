package pe.gob.osce.seguridad.services;

import org.json.JSONObject;

public interface CaptchaService {
	
	JSONObject performRecaptchaSiteVerify(String recaptchaResponseToken);

}
