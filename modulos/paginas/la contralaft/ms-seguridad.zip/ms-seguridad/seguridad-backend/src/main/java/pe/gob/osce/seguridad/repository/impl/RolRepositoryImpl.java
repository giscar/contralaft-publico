package pe.gob.osce.seguridad.repository.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import pe.gob.osce.seguridad.repository.EntidadRepository;
import pe.gob.osce.seguridad.repository.PrivilegioRepository;
import pe.gob.osce.seguridad.repository.RolRepository;
import pe.gob.osce.seguridad.seace.dto.ModuloDto;
import pe.gob.osce.seguridad.seace.dto.PrivilegioDto;
import pe.gob.osce.seguridad.seace.dto.RolDto;
import pe.gob.osce.seguridad.utils.DateUtil;


@Repository
public class RolRepositoryImpl implements RolRepository{

	@PersistenceContext
    private EntityManager em;
	
	@SuppressWarnings("unchecked")
	@Override
	@Transactional(readOnly=true)
	public List<RolDto> obtenerRolesByIdUsuario(String uid){
		
		List<RolDto> result = new ArrayList<RolDto>();
		StringBuilder sbQuery = new StringBuilder();
		sbQuery.append("SELECT ROL.N_ID_ROL, ROL.C_NOMROL, MOD.N_ID_MODULO, ROL.C_ESTADO ");
		sbQuery.append("FROM ADM.TBL_ADM_USU USU ");
		sbQuery.append("INNER JOIN ADM.DET_ADM_ROL_USU DRU ON (USU.N_ID_PERS = DRU.N_ID_PERS) ");
		sbQuery.append("INNER JOIN ADM.TBL_ADM_ROL ROL ON (DRU.N_ID_ROL = ROL.N_ID_ROL) ");
		sbQuery.append("INNER JOIN ADM.TBL_ADM_MOD MOD ON (ROL.N_ID_MODULO=MOD.N_ID_MODULO) ");
		sbQuery.append("WHERE USU.C_CODOID = :uid ");
		
		Query query = em.createNativeQuery(sbQuery.toString());
		query.setParameter("uid",uid);
		
		List<Object[]> listRpt = query.getResultList();
	
		for (Object[] obj : listRpt) {
			RolDto dto = new RolDto();
			BigDecimal idBD = new BigDecimal(0);
			idBD = (BigDecimal) obj[0];
			dto.setId(idBD.longValue());
			dto.setNombre(String.valueOf(obj[1]));
			ModuloDto moduloDto = new ModuloDto();
			idBD = (BigDecimal) obj[2];
			moduloDto.setId(idBD.longValue());
			dto.setModulo(moduloDto);
			result.add(dto);
		}
		return result;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	@Transactional(readOnly=true)
	public List<RolDto> obtenerRolesByIdModuloByIdUsuario(Long idModulo, String uid){
		
		List<RolDto> result = new ArrayList<RolDto>();
		StringBuilder sbQuery = new StringBuilder();
		sbQuery.append("SELECT ROL.N_ID_ROL, ROL.C_NOMROL, MOD.N_ID_MODULO, ROL.C_ESTADO ");
		sbQuery.append("FROM ADM.TBL_ADM_USU USU ");
		sbQuery.append("INNER JOIN ADM.DET_ADM_ROL_USU DRU ON (USU.N_ID_PERS = DRU.N_ID_PERS) ");
		sbQuery.append("INNER JOIN ADM.TBL_ADM_ROL ROL ON (DRU.N_ID_ROL = ROL.N_ID_ROL) ");
		sbQuery.append("INNER JOIN ADM.TBL_ADM_MOD MOD ON (ROL.N_ID_MODULO=MOD.N_ID_MODULO) ");
		sbQuery.append("WHERE MOD.N_ID_MODULO = :idModulo ");
		sbQuery.append("AND USU.C_CODOID = :uid ");
		
		Query query = em.createNativeQuery(sbQuery.toString());
		query.setParameter("idModulo",idModulo);
		query.setParameter("uid",uid);
		
		List<Object[]> listRpt = query.getResultList();
	
		for (Object[] obj : listRpt) {
			RolDto dto = new RolDto();
			BigDecimal idBD = new BigDecimal(0);
			idBD = (BigDecimal) obj[0];
			dto.setId(idBD.longValue());
			dto.setNombre(String.valueOf(obj[1]));
			ModuloDto moduloDto = new ModuloDto();
			idBD = (BigDecimal) obj[2];
			moduloDto.setId(idBD.longValue());
			dto.setModulo(moduloDto);
			result.add(dto);
		}
		return result;
	}
	
}
