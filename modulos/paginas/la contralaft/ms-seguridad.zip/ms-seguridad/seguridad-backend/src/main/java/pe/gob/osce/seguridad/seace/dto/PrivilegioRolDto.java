package pe.gob.osce.seguridad.seace.dto;

import java.util.Date;

import pe.gob.osce.seguridad.utils.DataTransferObjectUtil;

public class PrivilegioRolDto extends DataTransferObjectUtil {

	private static final long serialVersionUID = 1L;

    protected PrivilegioRolPKDto privilegioRolPK;

    private String estado;

    private Date fechaCreacion;

    private String usuarioCreacion;

    private Date ultimaFechaModificacion;

    private String ultimoUsuarioModificacion;

    private RolDto rol;

    private PrivilegioDto privilegio = new PrivilegioDto();

    public PrivilegioRolPKDto getPrivilegioRolPK() {
        return privilegioRolPK;
    }

    public void setPrivilegioRolPK(PrivilegioRolPKDto privilegioRolPK) {
        this.privilegioRolPK = privilegioRolPK;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    @Override
    public Date getFechaCreacion() {
        return fechaCreacion;
    }

    @Override
    public void setFechaCreacion(Date fechaCreacion) {
        this.fechaCreacion = fechaCreacion;
    }

    public String getUsuarioCreacion() {
        return usuarioCreacion;
    }

    public void setUsuarioCreacion(String usuarioCreacion) {
        this.usuarioCreacion = usuarioCreacion;
    }

    public Date getUltimaFechaModificacion() {
        return ultimaFechaModificacion;
    }

    public void setUltimaFechaModificacion(Date ultimaFechaModificacion) {
        this.ultimaFechaModificacion = ultimaFechaModificacion;
    }

    public String getUltimoUsuarioModificacion() {
        return ultimoUsuarioModificacion;
    }

    public void setUltimoUsuarioModificacion(String ultimoUsuarioModificacion) {
        this.ultimoUsuarioModificacion = ultimoUsuarioModificacion;
    }

    public RolDto getRol() {
        return rol;
    }

    public void setRol(RolDto rol) {
        this.rol = rol;
    }

    public PrivilegioDto getPrivilegio() {
        return privilegio;
    }

    public void setPrivilegio(PrivilegioDto privilegio) {
        this.privilegio = privilegio;
    }
}
