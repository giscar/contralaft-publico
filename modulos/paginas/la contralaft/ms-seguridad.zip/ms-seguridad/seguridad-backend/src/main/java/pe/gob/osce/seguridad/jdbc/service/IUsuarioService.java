package pe.gob.osce.seguridad.jdbc.service;

import java.util.List;

import pe.gob.osce.seguridad.dto.EntidadDto;
import pe.gob.osce.seguridad.jdbc.entity.Usuario;

public interface IUsuarioService {
	
	public Usuario findByUsername(String username);
	
	public List<EntidadDto> getListaEntidadesByOID(String username);
}
