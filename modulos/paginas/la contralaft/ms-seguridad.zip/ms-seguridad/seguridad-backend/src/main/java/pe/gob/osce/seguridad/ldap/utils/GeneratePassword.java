package pe.gob.osce.seguridad.ldap.utils;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

public class GeneratePassword {
	
	public BCryptPasswordEncoder bCryptPasswordEncoder = new BCryptPasswordEncoder();

	
	public static void main(String[] args) {
		String password ="12345";
		for (int i = 0; i < 4; i++) {
			//String passwordEncryp= bCryptPasswordEncoder.get
		}

	}

}
