package pe.gob.osce.seguridad.component;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ldap.core.LdapTemplate;
import org.springframework.ldap.filter.EqualsFilter;
import org.springframework.ldap.filter.Filter;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.LockedException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.stereotype.Component;

import pe.gob.osce.seguridad.seace.dto.PerfilDto;
import pe.gob.osce.seguridad.seace.dto.UsuarioDto;
import pe.gob.osce.seguridad.services.PerfilService;
import pe.gob.osce.seguridad.services.UsuarioService;
import pe.gob.osce.seguridad.seace.enums.EstadoCuentaUsuarioState;

@Component
public class CustomAuthenticationProvider implements AuthenticationProvider {

	
	@Autowired
	private LdapTemplate ldapTemplate;
	
	@Autowired
	private UsuarioService usuarioService;
	
	@Autowired
	private PerfilService perfilService;
	
	@Override
	public Authentication authenticate(Authentication authentication) throws AuthenticationException {
		final String name  = authentication.getName().trim();
        final String password = authentication.getCredentials().toString();
         
        final Filter filter= new EqualsFilter("uid", name);
        
                
        final boolean autenticated=ldapTemplate.authenticate("", filter.toString(), password);
        
        System.out.println(ldapTemplate.toString());
        
        //if (shouldAuthenticateAgainstThirdPartySystem()) {
        if (autenticated) {
        	
        	List<PerfilDto> listaPerfiles = perfilService.obtenerPerfilesByIdUsuario(name);
        
        	//UserDetails user = usuarioService.loadUserByUsername(name);
        	UsuarioDto usuarioDto = usuarioService.obtenerEstadoUsuarioLogin(name);
            // use the credentials
            // and authenticate against the third-party system
            //return new UsernamePasswordAuthenticationToken(name, password, user.getAuthorities());
        	if (usuarioDto.getEstado().equals(EstadoCuentaUsuarioState.BLQEX.getKey())) {
        		throw new LockedException("101|El usuario se encuentra bloqueado. Para volver a activarlo utilice la opción ¿Olvidó su contraseña?");
        		
        	}else if(usuarioDto.getEstado().equals(EstadoCuentaUsuarioState.BLQCA.getKey())) {
        		throw new LockedException("102|El usuario se encuentra bloqueado. Para volver a activarlo utilice la opción ¿Olvidó su contraseña?");
        		
        	}else if(usuarioDto.getEstado().equals(EstadoCuentaUsuarioState.INACTIVO.getKey())) {
        		throw new LockedException("103|El usuario no se encuentra activo o no cuenta con permisos de acceso. Comuníquese con el administrador");
        		
        	}else if(usuarioDto.getEstado().equals(EstadoCuentaUsuarioState.BLQIF.getKey())) {
        		throw new LockedException("104|El usuario se encuentra bloqueado por superar el limite de intentos fallidos");
        	
        	}else if(listaPerfiles!=null && listaPerfiles.size()>1) {
        		throw new LockedException("El usuario tiene dos perfiles activos, comuníquese con el administrador del sistema");
        		
        	}else {
        		return new UsernamePasswordAuthenticationToken(name, password, null);
        	}
        	
        	
        } else {
            throw new BadCredentialsException("El usuario o contraseña incorrectos");
        }
	}

	@Override
	public boolean supports(Class<?> authentication) {
		// TODO Auto-generated method stub
		//return false;
		 //return (UsernamePasswordAuthenticationToken.class.isAssignableFrom(authentication));
		return authentication.equals(UsernamePasswordAuthenticationToken.class);
	}
	
}
