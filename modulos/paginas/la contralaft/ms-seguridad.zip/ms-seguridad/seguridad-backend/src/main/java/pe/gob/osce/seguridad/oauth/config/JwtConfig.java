package pe.gob.osce.seguridad.oauth.config;

public class JwtConfig {
	public static final String LLAVE_SECRETA="123";
	public static final String RSA_PRIVADA="-----BEGIN RSA PRIVATE KEY-----\r\n" + 
			"MIIEogIBAAKCAQEAyUXvBNuZJETLielIT7eAabtBXxT7xmDHUsiDEaSoYpCV9xYu\r\n" + 
			"SEUACdE5jB4AGGd0Kxt5x52eT2hpCO0z0SuHgi43BB1f7GDxxYJT8791sWQriGHL\r\n" + 
			"hgf0qZRE2muvWQ6zIYyZzqLFjLQU4D5ArVAtbjpzNIVed/kdF5aCEZyHX99XHuTD\r\n" + 
			"Iu9Kssr4wy5mOl5bz5ZZCg8dyRHHfYUELXl1e80Q2/PpU1ceWE8riFUtwSkcrCx9\r\n" + 
			"MLjiTWoasQ5ANcVKMteJfNtyZmxvVsCYDDyzvn0Va5keNp+w3xLrEroC9ALElqfn\r\n" + 
			"3M5q8xEFDn6QsSIjhtsI9iVOb2gQ96Nhv2ymeQIDAQABAoIBAHyxwOUHj5bysA7e\r\n" + 
			"4hfRHdNjWZqoi1tZteNJqjoSAugdn2sW6NGJPf7XCooORAzaexQBz66lreCQVRJc\r\n" + 
			"sk+SYj96lkcMU9NENEUi+xP1t9qQro+t1sNQxnkRDJ8tO9M20i+kxd1I5o7HOm+6\r\n" + 
			"4aL+G0dBGwKc5ev5/9YPPsHecdgokkHkcsqEzx2wJw0iPDnSQotZQji4vTLXluRS\r\n" + 
			"/x2kEEW8HgQEaqVtJ2HwpDyP0tg8p3Cc4LN4c4VL9Xl3ZqZZqaDlo65XIXj+B+nc\r\n" + 
			"sgGausylAbwH1ozMewfusRpbNeLhe8kGiAFj6Ed+0TzyBqnf4ptyMO++kwZ4/SvB\r\n" + 
			"gz7B18kCgYEA8CI7f63yg8it86dxoom1X/wpZNucmsKnEK1FXspUp9Wwsa5YfdGR\r\n" + 
			"shfHzZOD8HaA22GGuit6RPyh0Y2LyxhdcB6J9bfSHyy9r8A2FFpcoKmy0pSTQgQT\r\n" + 
			"+0MWcB1pRsecTX4qvmKdIa4tbiIm8hKPnpSQ7Th0YPd8cE+8gaXonXcCgYEA1pJj\r\n" + 
			"9BUJ7ohdEz+4A6/C/wtAlMkHp0HBbHOaILyEfXyr08I9slbpCqeawqqhjSOegmcb\r\n" + 
			"VMefsb7l5vjH2cvg72//HOF0aYgyayaVb4q0DLrHkp5EWkur4Q+/8dp3W847K46o\r\n" + 
			"Qdp1n4BjxIxoi4P8jjtV3wxlAl6ck4yVdSAhF48CgYBWZFp3kwM++kHq+QDe8yA3\r\n" + 
			"yiayTHhJDWLBkzTz52MRhsWtBwZ7LZx3MCsIANxk9J1jT/ECpYW1sBYfqAb1KGzl\r\n" + 
			"W3dS2bFU2encgxBxvhi5DJRzQlTAWWs+6GH4L/yiJEpNbui92giiB2H8z3inepoE\r\n" + 
			"+Xoyfi8Qe7lfRrCRDDll/QKBgFVuEYfDvKGQ/2XDj9M/7mY3J65VX8uy/XzdhfcU\r\n" + 
			"t7dypML56jCQM9a/JnntD8cu8FRBEvutQyK0u7o7QO6xIsySDcOE7CF8TX6l7Qds\r\n" + 
			"9QTAdOcmRlahHDzOVYDIl48gzCQqd0lI3l3z80T1Fka99Rb3/teAitLnsnV4mqT4\r\n" + 
			"dtR3AoGAVC9a1d9RVujp9fahOmqXz1a2Z3t6iB4+9RHPv9jC9rdh+XTvRUbPKSz5\r\n" + 
			"o/WWdr0KvAjc4k/ndXVBpfXFrje0NXQHiu9dAWZG8IBFuiVCNFju4vsfxCMfv6GV\r\n" + 
			"U1wo9ezsBTW2kKQRvjBggBnlKxf7cqIFIIFa1YCH5X1SEyinvQE=\r\n" + 
			"-----END RSA PRIVATE KEY-----";
	
	public static final String RSA_PUBLICA="-----BEGIN PUBLIC KEY-----\r\n" + 
			"MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAyUXvBNuZJETLielIT7eA\r\n" + 
			"abtBXxT7xmDHUsiDEaSoYpCV9xYuSEUACdE5jB4AGGd0Kxt5x52eT2hpCO0z0SuH\r\n" + 
			"gi43BB1f7GDxxYJT8791sWQriGHLhgf0qZRE2muvWQ6zIYyZzqLFjLQU4D5ArVAt\r\n" + 
			"bjpzNIVed/kdF5aCEZyHX99XHuTDIu9Kssr4wy5mOl5bz5ZZCg8dyRHHfYUELXl1\r\n" + 
			"e80Q2/PpU1ceWE8riFUtwSkcrCx9MLjiTWoasQ5ANcVKMteJfNtyZmxvVsCYDDyz\r\n" + 
			"vn0Va5keNp+w3xLrEroC9ALElqfn3M5q8xEFDn6QsSIjhtsI9iVOb2gQ96Nhv2ym\r\n" + 
			"eQIDAQAB\r\n" + 
			"-----END PUBLIC KEY-----";
}
