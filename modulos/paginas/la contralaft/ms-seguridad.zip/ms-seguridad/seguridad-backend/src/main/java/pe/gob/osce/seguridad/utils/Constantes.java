package pe.gob.osce.seguridad.utils;

public class Constantes {

	public static final String OK = "OK";
	public static final String SI = "S";
	public static final String RESP_CAPTCHA = "captcha";
	public static final String RESP_SESION = "sesion";
	public static final String RESP_ENTIDADES = "entidades";
	public static final String RESP_PRIVILEGIOS = "privilegios";
	//private static final String SITE_SECRET = "6LcSXN8UAAAAAOO1BkqGP0K2liOuij0vvqF6My65"; //hidden
	//public static final String SITE_SECRET = "6Lcr_t8UAAAAAPgxMRf8565Y24objO5r4_oThamu";//apoyo
	public static final String SITE_SECRET = "6Le47ucUAAAAAIN7e2UtkwrApxXhPT45FL-1iOIA";
	public static final String SECRET_PARAM = "secret";
	public static final String RESPONSE_PARAM = "response";
	public static final String G_RECAPTCHA_RESPONSE = "g-recaptcha-response";
	public static final String SITE_VERIFY_URL = "https://www.google.com/recaptcha/api/siteverify";
	
	public static final long COD_MODULO_SELECCION = 7L;
	public static final long COD_MODULO_CONTRATOS = 10L;
	
}

