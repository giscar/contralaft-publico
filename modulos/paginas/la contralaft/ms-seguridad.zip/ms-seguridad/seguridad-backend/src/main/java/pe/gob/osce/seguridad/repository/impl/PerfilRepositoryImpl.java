package pe.gob.osce.seguridad.repository.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import pe.gob.osce.seguridad.repository.PerfilRepository;
import pe.gob.osce.seguridad.seace.dto.PerfilDto;


@Repository
public class PerfilRepositoryImpl implements PerfilRepository{

	@PersistenceContext
    private EntityManager em;
	
	@SuppressWarnings("unchecked")
	@Override
	@Transactional(readOnly=true)
	public List<PerfilDto> obtenerPerfilesByIdUsuario(List<Long> idModulos, String uid){
		
		List<PerfilDto> result = new ArrayList<PerfilDto>();
		StringBuilder sbQuery = new StringBuilder();
		sbQuery.append("SELECT DISTINCT PRF.N_ID_PERFIL, PRF.C_NOMPRF ");
		sbQuery.append("FROM ADM.TBL_ADM_USU USU ");
		sbQuery.append("INNER JOIN ADM.DET_ADM_ROL_USU DRU ON (USU.N_ID_PERS = DRU.N_ID_PERS) ");
		sbQuery.append("INNER JOIN ADM.TBL_ADM_ROL ROL ON (DRU.N_ID_ROL = ROL.N_ID_ROL) ");
		sbQuery.append("INNER JOIN ADM.TBL_ADM_MOD MOD ON (ROL.N_ID_MODULO=MOD.N_ID_MODULO) ");
		sbQuery.append("INNER JOIN ADM.TBL_ADM_PRF PRF ON (PRF.N_ID_PERFIL = DRU.N_ID_PERFIL) ");
		sbQuery.append("WHERE USU.C_CODOID = :uid ");
		
		Query query = em.createNativeQuery(sbQuery.toString());
		//query.setParameter("idModulos",idModulos);
		query.setParameter("uid",uid);
		
		List<Object[]> listRpt = query.getResultList();
	
		for (Object[] obj : listRpt) {
			PerfilDto dto = new PerfilDto();
			BigDecimal idBD = new BigDecimal(0);
			idBD = (BigDecimal) obj[0];
			dto.setId(idBD.longValue());
			dto.setNombre(String.valueOf(obj[1]));
			result.add(dto);
		}
		return result;
	}
	
}
