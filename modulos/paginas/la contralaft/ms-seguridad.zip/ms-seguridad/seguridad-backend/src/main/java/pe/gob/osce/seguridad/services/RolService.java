package pe.gob.osce.seguridad.services;

import java.util.List;

import pe.gob.osce.seguridad.seace.dto.RolDto;

public interface RolService {
	
	public List<RolDto> obtenerRolesByIdUsuario(String idUsuario);
}
