package pe.gob.osce.seguridad.jdbc.entity;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

@Entity
@Table(name = "TBL_SEG_USUARIO", schema = "SEG")
public class Usuario implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "SQ_N_ID_USUARIO", sequenceName = "SQ_N_ID_USUARIO", schema = "SEG", allocationSize = 1)
	@GeneratedValue(generator = "SQ_N_ID_USUARIO", strategy = GenerationType.SEQUENCE)
	@Column(name = "N_ID_USUARIO")
	private Long idUsuario;

	@Column(name = "N_ID_PERSONA")
	private String idPersona;

	@Column(name = "C_USERNAME")
	private String username;

	@Column(name = "C_PASSWORD")
	private String password;

	@Column(name = "C_EMAIL1")
	private String email1;

	@Column(name = "C_EMAIL2")
	private String email2;

	@Column(name = "C_TIPO_USUARIO")
	private Long tipoUsuario;

	@Column(name = "N_EST_USUARIO")
	private Long estadoUsuario;

	@Column(name = "N_EST_REGISTRO")
	private Long estadoRegistro;

	@Column(name = "C_USU_REG")
	private String usuarioCreacion;

	@Column(name = "D_FEC_REG")
	private Date fechaCreacion;

	@Column(name = "C_USU_MOD")
	private String usuarioModificacion;

	@Column(name = "D_FEC_MOD")
	private Date fechaModificacion;

	@ManyToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	@JoinTable(name="DET_SEG_USU_ROL",joinColumns = @JoinColumn(name="N_ID_USUARIO"),inverseJoinColumns = @JoinColumn(name="N_ID_ROL"),
	uniqueConstraints = {@UniqueConstraint(columnNames = { "N_ID_USUARIO","N_ID_ROL"})})
	private List<Rol> roles;

	public Long getIdUsuario() {
		return idUsuario;
	}

	public void setIdUsuario(Long idUsuario) {
		this.idUsuario = idUsuario;
	}

	public String getIdPersona() {
		return idPersona;
	}

	public void setIdPersona(String idPersona) {
		this.idPersona = idPersona;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getEmail1() {
		return email1;
	}

	public void setEmail1(String email1) {
		this.email1 = email1;
	}

	public String getEmail2() {
		return email2;
	}

	public void setEmail2(String email2) {
		this.email2 = email2;
	}

	public Long getTipoUsuario() {
		return tipoUsuario;
	}

	public void setTipoUsuario(Long tipoUsuario) {
		this.tipoUsuario = tipoUsuario;
	}

	public Long getEstadoUsuario() {
		return estadoUsuario;
	}

	public void setEstadoUsuario(Long estadoUsuario) {
		this.estadoUsuario = estadoUsuario;
	}

	public Long getEstadoRegistro() {
		return estadoRegistro;
	}

	public void setEstadoRegistro(Long estadoRegistro) {
		this.estadoRegistro = estadoRegistro;
	}

	public String getUsuarioCreacion() {
		return usuarioCreacion;
	}

	public void setUsuarioCreacion(String usuarioCreacion) {
		this.usuarioCreacion = usuarioCreacion;
	}

	public Date getFechaCreacion() {
		return fechaCreacion;
	}

	public void setFechaCreacion(Date fechaCreacion) {
		this.fechaCreacion = fechaCreacion;
	}

	public String getUsuarioModificacion() {
		return usuarioModificacion;
	}

	public void setUsuarioModificacion(String usuarioModificacion) {
		this.usuarioModificacion = usuarioModificacion;
	}

	public Date getFechaModificacion() {
		return fechaModificacion;
	}

	public void setFechaModificacion(Date fechaModificacion) {
		this.fechaModificacion = fechaModificacion;
	}

	public List<Rol> getRoles() {
		return roles;
	}

	public void setRoles(List<Rol> roles) {
		this.roles = roles;
	}

	
}
