package pe.gob.osce.seguridad.services.impl;

import java.util.ArrayList;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import pe.gob.osce.seguridad.dto.UsuarioSesionDto;
import pe.gob.osce.seguridad.repository.PrivilegioRepository;
import pe.gob.osce.seguridad.seace.dto.PrivilegioDto;
import pe.gob.osce.seguridad.seace.dto.RolDto;
import pe.gob.osce.seguridad.seace.enums.RolType;
import pe.gob.osce.seguridad.services.PrivilegioService;
import pe.gob.osce.seguridad.services.RolService;
import pe.gob.osce.seguridad.utils.Constantes;

@Service
@Transactional(readOnly = true)
public class PrivilegioServiceImpl implements PrivilegioService{
	
	private Logger logger = LoggerFactory.getLogger(PrivilegioServiceImpl.class);

	@Autowired
	private PrivilegioRepository privilegioRepository;
	
	@Autowired
	private RolService rolService;


	@Override
	@Transactional(readOnly=true)
	public List<PrivilegioDto> obtenerPrivilegios(UsuarioSesionDto usuarioDto) {
		
		List<PrivilegioDto> listaPrivilegios = new ArrayList<PrivilegioDto>();
		try {
			
			listaPrivilegios = privilegioRepository.obtenerPrivilegiosByUsuario(Constantes.COD_MODULO_CONTRATOS, -1L, usuarioDto.getIdEntidadSeleccionada(), usuarioDto.getUid());
				
		} catch (Exception e) {
			logger.error(e.getMessage());
		}

		return listaPrivilegios;
	}
	
	@Override
	@Transactional(readOnly=true)
	public List<String> obtenerPrivilegiosSoloAcciones(UsuarioSesionDto usuarioDto) {
		
		List<String> listaPrivilegios = new ArrayList<String>();
		try {
			boolean tienePermisosTodasEntidades = false;
			List<RolDto> listaRoles = rolService.obtenerRolesByIdUsuario(usuarioDto.getUid());
			if(listaRoles!=null && !listaRoles.isEmpty()) {
				for(RolDto rol: listaRoles) {
					if(rol.getId().equals(RolType.FUNCIONARIO_USUARIO_DE_CONTROL_Y_FISCALIZACION.getKey()) ||
							rol.getId().equals(RolType.ACCESO_A_CONTRATOS_OSCE.getKey()) ||
							rol.getId().equals(RolType.USUARIO_PLATAFORMA_CONTRATOS.getKey())
							) {
						tienePermisosTodasEntidades=true;
					}
				}
			}
			
			if(tienePermisosTodasEntidades) {
				listaPrivilegios = privilegioRepository.obtenerPrivilegiosByUsuarioSoloAccionesTodasEntidades(Constantes.COD_MODULO_CONTRATOS, usuarioDto.getUid());
			}else {
				listaPrivilegios = privilegioRepository.obtenerPrivilegiosByUsuarioSoloAcciones(Constantes.COD_MODULO_CONTRATOS, -1L, usuarioDto.getIdEntidadSeleccionada(), usuarioDto.getUid());
			}
				
		} catch (Exception e) {
			logger.error(e.getMessage());
		}

		return listaPrivilegios;
	}
        

}
