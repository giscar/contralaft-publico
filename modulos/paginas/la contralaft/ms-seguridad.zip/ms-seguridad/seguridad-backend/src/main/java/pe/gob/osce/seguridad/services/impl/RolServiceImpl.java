package pe.gob.osce.seguridad.services.impl;

import java.util.ArrayList;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import pe.gob.osce.seguridad.repository.RolRepository;
import pe.gob.osce.seguridad.seace.dto.RolDto;
import pe.gob.osce.seguridad.services.RolService;
import pe.gob.osce.seguridad.utils.Constantes;

@Service
@Transactional(readOnly = true)
public class RolServiceImpl implements RolService{
	
	private Logger logger = LoggerFactory.getLogger(RolServiceImpl.class);

	@Autowired
	private RolRepository rolRepository;


	@Override
	@Transactional(readOnly=true)
	public List<RolDto> obtenerRolesByIdUsuario(String idUsuario) {
		
		List<RolDto> listaRoles = new ArrayList<RolDto>();
		try {
			
			listaRoles = rolRepository.obtenerRolesByIdUsuario(idUsuario);
				
		} catch (Exception e) {
			logger.error(e.getMessage());
		}

		return listaRoles;
	}    

}
