package pe.gob.osce.seguridad.services.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import pe.gob.osce.seguridad.repository.UsuarioRepository;
import pe.gob.osce.seguridad.seace.dto.UsuarioDto;
import pe.gob.osce.seguridad.services.UsuarioService;

@Service
@Transactional(readOnly = true)
public class UsuarioServiceImpl implements UsuarioService{
	
	private Logger logger = LoggerFactory.getLogger(UsuarioServiceImpl.class);

	@Autowired
	private UsuarioRepository usuarioRepository;


	@Override
	@Transactional(readOnly=true)
	public UsuarioDto obtenerEstadoUsuarioLogin(String username) {
		
		UsuarioDto usuarioDto = new UsuarioDto();
		try {
			
			usuarioDto = usuarioRepository.obtenerEstadoUsuarioByUserName(username);
				
		} catch (Exception e) {
			logger.error(e.getMessage());
		}

		return usuarioDto;
	}
	
	@Override
	@Transactional(readOnly=true)
	public UsuarioDto obtenerUsuarioLogin(String username) {
		
		UsuarioDto usuarioDto = new UsuarioDto();
		try {
			
			usuarioDto = usuarioRepository.obtenerUsuarioByUserName(username);
				
		} catch (Exception e) {
			logger.error(e.getMessage());
		}

		return usuarioDto;
	}
        

}
