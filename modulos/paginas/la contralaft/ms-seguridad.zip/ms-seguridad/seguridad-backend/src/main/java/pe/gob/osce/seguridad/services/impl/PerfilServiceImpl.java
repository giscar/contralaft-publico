package pe.gob.osce.seguridad.services.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import pe.gob.osce.seguridad.repository.PerfilRepository;
import pe.gob.osce.seguridad.repository.RolRepository;
import pe.gob.osce.seguridad.seace.dto.PerfilDto;
import pe.gob.osce.seguridad.seace.dto.RolDto;
import pe.gob.osce.seguridad.services.PerfilService;
import pe.gob.osce.seguridad.services.RolService;
import pe.gob.osce.seguridad.utils.Constantes;

@Service
@Transactional(readOnly = true)
public class PerfilServiceImpl implements PerfilService{
	
	private Logger logger = LoggerFactory.getLogger(PerfilServiceImpl.class);

	@Autowired
	private PerfilRepository perfilRepository;


	@Override
	@Transactional(readOnly=true)
	public List<PerfilDto> obtenerPerfilesByIdUsuario(String idUsuario) {
		
		List<PerfilDto> listaPerfiles = new ArrayList<PerfilDto>();
		try {
			
			List<Long> modulos = Arrays.asList(Constantes.COD_MODULO_SELECCION, Constantes.COD_MODULO_CONTRATOS);
			listaPerfiles = perfilRepository.obtenerPerfilesByIdUsuario(modulos, idUsuario);
				
		} catch (Exception e) {
			logger.error(e.getMessage());
		}

		return listaPerfiles;
	}    

}
