package pe.gob.osce.seguridad.repository.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import pe.gob.osce.seguridad.repository.EntidadRepository;
import pe.gob.osce.seguridad.repository.PrivilegioRepository;
import pe.gob.osce.seguridad.repository.UsuarioRepository;
import pe.gob.osce.seguridad.seace.dto.PersonaDto;
import pe.gob.osce.seguridad.seace.dto.PrivilegioDto;
import pe.gob.osce.seguridad.seace.dto.UsuarioDto;
import pe.gob.osce.seguridad.utils.DateUtil;


@Repository
public class UsuarioRepositoryImpl implements UsuarioRepository{

	@PersistenceContext
    private EntityManager em;
	
	@SuppressWarnings("unchecked")
	@Override
	@Transactional(readOnly=true)
	public UsuarioDto obtenerEstadoUsuarioByUserName(String userName){
		
		UsuarioDto result = new UsuarioDto();
		StringBuilder sbQuery = new StringBuilder();
		sbQuery.append("SELECT USU.C_ESTADO ");
		sbQuery.append("  FROM ADM.TBL_ADM_USU USU");
		sbQuery.append(" WHERE USU.C_CODOID = :userName ");
		
		Query query = em.createNativeQuery(sbQuery.toString());
		query.setParameter("userName",userName);
		
		List<Object> listRpt = query.getResultList();
	
		for (Object obj : listRpt) {
			UsuarioDto dto = new UsuarioDto();
			dto.setEstado(String.valueOf(obj));
			result = dto;
		}
		return result;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	@Transactional(readOnly=true)
	public UsuarioDto obtenerUsuarioByUserName(String userName){
		
		UsuarioDto usuarioDto = new UsuarioDto();
		StringBuilder sbQuery = new StringBuilder();
		sbQuery.append("SELECT PERS.N_ID_PERS, PERS.C_TIPDOC, PERS.C_NOMBRE, PERS.C_APELLID, PERS.C_NOMCOM, PERS.C_EMAIL, USU.C_ESTADO ");
		sbQuery.append("FROM ADM.TBL_ADM_USU USU ");
		sbQuery.append("INNER JOIN ADM.TBL_ADM_PERSONA PERS ");
		sbQuery.append("ON (USU.N_ID_PERS = PERS.N_ID_PERS) ");
		
		sbQuery.append("WHERE USU.C_CODOID = :userName ");
		
		Query query = em.createNativeQuery(sbQuery.toString());
		query.setParameter("userName",userName);
		
		List<Object[]> resultTemp = query.getResultList();
		
		
		if (resultTemp != null && resultTemp.size() > 0) {
			
			PersonaDto personaDto = new PersonaDto();
			BigDecimal idBD = new BigDecimal(0);
			idBD = (BigDecimal) resultTemp.get(0)[0];
			personaDto.setId(idBD.longValue() );
			personaDto.setTipoDocumento((String) resultTemp.get(0)[1]);
			personaDto.setNombres((String) resultTemp.get(0)[2]);
			personaDto.setApellidos((String) resultTemp.get(0)[3]);
			personaDto.setNombreCompleto((String) resultTemp.get(0)[4]);
			personaDto.setEmail((String) resultTemp.get(0)[5]);
			usuarioDto.setPersona(personaDto);
			usuarioDto.setEstado((String) resultTemp.get(0)[6]);
		}
		return usuarioDto;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	//@Transactional(readOnly=true)
	public boolean actualizarEstadoUsuario(String userName, String estado){
		
		UsuarioDto result = new UsuarioDto();
		StringBuilder sbQuery = new StringBuilder();
		sbQuery.append("UPDATE ADM.TBL_ADM_USU USU SET USU.C_ESTADO = : estado ");
		sbQuery.append("WHERE USU.C_CODOID = :userName ");
		
		Query query = em.createNativeQuery(sbQuery.toString());
		query.setParameter("estado",estado);
		query.setParameter("userName",userName);
		
		Object resultUpdate = query.getSingleResult();
		if (result != null) {
			
		}
		
		return true;
	}
	
	
}
