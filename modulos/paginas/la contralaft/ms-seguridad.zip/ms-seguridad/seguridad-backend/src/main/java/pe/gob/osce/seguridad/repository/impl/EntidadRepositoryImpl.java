package pe.gob.osce.seguridad.repository.impl;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import pe.gob.osce.seguridad.repository.EntidadRepository;


@Repository
public class EntidadRepositoryImpl implements EntidadRepository{

	@PersistenceContext
    private EntityManager em;
	
	@SuppressWarnings("unchecked")
	@Override
	@Transactional(readOnly=true)
	public List<Object[]> buscarEntidadesxOID(String oid){
		StringBuilder jpql = new StringBuilder();
		jpql.append("SELECT ORG.N_ID_ORGAN AS CODIGO, ORG.C_NOMORG AS NOMBRE ");
		jpql.append("FROM ADM.DET_ADM_USU_ORG USUORG ");
		jpql.append("INNER JOIN ADM.TBL_ADM_ORG ORG ON USUORG.N_ID_ORGAN = ORG.N_ID_ORGAN ");
		jpql.append("INNER JOIN ADM.TBL_ADM_USU USU ON USUORG.N_ID_PERS = USU.N_ID_PERS ");
		jpql.append("WHERE USUORG.C_ESTADO = 'ACTIV' ");
		jpql.append("AND ORG.N_ID_TIPORG =1 ");
		jpql.append("AND USU.C_CODOID = :oid ");
		Query query = em.createNativeQuery(jpql.toString());
		if(oid != null) {
			query.setParameter("oid",oid);
		}
		List<Object[]> lista = query.getResultList();
		return lista;
	}
	
	@SuppressWarnings("unchecked")
	@Override
	@Transactional(readOnly=true)
	public List<Object[]> obtenerTodasEntidades(){
		StringBuilder jpql = new StringBuilder();
		jpql.append("SELECT ORG.N_ID_ORGAN AS CODIGO, ORG.C_NOMORG AS NOMBRE ");
		jpql.append("FROM ADM.TBL_ADM_ORG ORG ");
		jpql.append("WHERE ORG.C_ESTADO = 'ACTIV' ");
		Query query = em.createNativeQuery(jpql.toString());
		List<Object[]> lista = query.getResultList();
		return lista;
	}
}
