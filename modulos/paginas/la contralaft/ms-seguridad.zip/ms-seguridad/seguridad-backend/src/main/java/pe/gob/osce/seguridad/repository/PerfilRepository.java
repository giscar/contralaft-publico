package pe.gob.osce.seguridad.repository;

import java.util.List;

import pe.gob.osce.seguridad.seace.dto.PerfilDto;

public interface PerfilRepository{

	List<PerfilDto> obtenerPerfilesByIdUsuario(List<Long> idModulos, String uid);
	
}
