package pe.gob.osce.seguridad.ldap.utils;

import java.io.File;
import java.util.Properties;

public class UsuarioLDAPUtil {
	
	
	public static  String ldapHost = new String();
	public static  String password = new String();
	public static  String loginDN = new String();
	public static  String ldapPort = new String();
	public static  String BASE_DN = new String();
	public static  String USER_FILTER = new String();
	public static  String USER_FILTER_UID = new String();
	public static  String URL = new String();
	public static Properties propertie = new Properties();
	public static  String PATHFILENAME_CFG = "/fsapp/seace3/cfg/usuarioldap.properties";
	public static  String PATHFILENAME_CFG_DIR = "/fsapp/seace3/cfg/";
	public static  String PATHFILENAME_CFG_FILE = "usuarioldap.properties";
	
	static {
		try {
			//System.out.println("Entro a properties");
			propertie = PropertiesUtil.loadFileSystemProperties(PATHFILENAME_CFG);
			//propertie = PropertiesUtil.loadFileSystemProperties(PATHFILENAME_CFG_DIR,PATHFILENAME_CFG_FILE);
			ldapHost=(propertie.getProperty("ldapHost"));
			password=(propertie.getProperty("password"));
			loginDN=(propertie.getProperty("loginDN"));
			ldapPort=(propertie.getProperty("ldapPort"));
			BASE_DN=(propertie.getProperty("BASE_DN"));
			USER_FILTER=(propertie.getProperty("USER_FILTER"));
			URL=("ldap://" + ldapHost + ":" + ldapPort + "/");
			USER_FILTER_UID=("uid={0}");
			
			//System.out.println("Entro a properties");
			//System.out.println(propertie);
		
		/*	
		File file = new File(PATHFILENAME_CFG);
		if (!file.exists()) {
			System.out.println("No existe");
		}else {
			System.out.println("Existe");
			System.out.println(propertie);
		}
		*/
						
		} catch (Exception e) {
			//log.error(e.getMessage(), e);
			System.out.println( e);
			//System.out.println( e.getMessage());
			//System.out.println("Error");
		}
	}
	
	public UsuarioLDAPUtil() {
		//System.out.println("Entro a properties constructor");
		//System.out.println(propertie);
	}
	
	
}
