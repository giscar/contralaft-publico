package pe.gob.osce.seguridad.services;

import java.util.List;

import pe.gob.osce.seguridad.seace.dto.PerfilDto;

public interface PerfilService {
	
	public List<PerfilDto> obtenerPerfilesByIdUsuario(String idUsuario);
}
