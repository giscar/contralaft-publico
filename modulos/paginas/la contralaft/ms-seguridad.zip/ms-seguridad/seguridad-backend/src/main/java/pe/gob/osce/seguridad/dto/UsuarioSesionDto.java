package pe.gob.osce.seguridad.dto;

import java.io.Serializable;

public class UsuarioSesionDto implements Serializable {

	private static final long serialVersionUID = 1L;
	
	private String uid;	
	private String nombreSesion;
	private String email;
	private Long idEntidadSeleccionada;
	public String getUid() {
		return uid;
	}
	public void setUid(String uid) {
		this.uid = uid;
	}
	public String getNombreSesion() {
		return nombreSesion;
	}
	public void setNombreSesion(String nombreSesion) {
		this.nombreSesion = nombreSesion;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public Long getIdEntidadSeleccionada() {
		return idEntidadSeleccionada;
	}
	public void setIdEntidadSeleccionada(Long idEntidadSeleccionada) {
		this.idEntidadSeleccionada = idEntidadSeleccionada;
	}
	

}
