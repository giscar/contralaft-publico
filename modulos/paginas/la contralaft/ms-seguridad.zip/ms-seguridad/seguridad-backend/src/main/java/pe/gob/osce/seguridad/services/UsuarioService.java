package pe.gob.osce.seguridad.services;

import pe.gob.osce.seguridad.seace.dto.UsuarioDto;

public interface UsuarioService {
	
	public UsuarioDto obtenerEstadoUsuarioLogin(String userName);
	public UsuarioDto obtenerUsuarioLogin(String userName);
}
