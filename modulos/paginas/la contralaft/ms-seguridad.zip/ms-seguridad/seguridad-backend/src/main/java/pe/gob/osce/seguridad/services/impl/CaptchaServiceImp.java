package pe.gob.osce.seguridad.services.impl;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

import org.json.JSONObject;
import org.json.JSONTokener;
import org.springframework.stereotype.Service;

import pe.gob.osce.seguridad.services.CaptchaService;
import pe.gob.osce.seguridad.utils.Constantes;

@Service
public class CaptchaServiceImp implements CaptchaService{

	@Override
	public JSONObject performRecaptchaSiteVerify(String recaptchaResponseToken) {
		
		 URL url=null;
		 StringBuilder postData =null;
		try {
			url = new URL(Constantes.SITE_VERIFY_URL);
			 postData = new StringBuilder();
			 addParam(postData, Constantes.SECRET_PARAM, Constantes.SITE_SECRET);
			 addParam(postData, Constantes.RESPONSE_PARAM, recaptchaResponseToken);		 
			 
		} catch (MalformedURLException | UnsupportedEncodingException e) {			
			e.printStackTrace();
		}
		
		return postAndParseJSON(url, postData.toString());
			
	}
	
	private JSONObject postAndParseJSON(URL url, String postData) {
		
		JSONTokener jsonTokener=null;
		try {
			 HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();
			    urlConnection.setDoOutput(true);
			    urlConnection.setRequestMethod("POST");
			    urlConnection.setRequestProperty(
			            "Content-Type", "application/x-www-form-urlencoded");
			    urlConnection.setRequestProperty(
			            "charset", StandardCharsets.UTF_8.displayName());
			    urlConnection.setRequestProperty(
			            "Content-Length", Integer.toString(postData.length()));
			    urlConnection.setUseCaches(false);
			    urlConnection.getOutputStream()
			            .write(postData.getBytes(StandardCharsets.UTF_8));
			    jsonTokener = new JSONTokener(urlConnection.getInputStream());
		} catch (Exception e) {
			e.printStackTrace();
		}
	   
	    return new JSONObject(jsonTokener);
	  }
	
	private StringBuilder addParam(
	          StringBuilder postData, String param, String value)
	          throws UnsupportedEncodingException {
	    if (postData.length() != 0) {
	      postData.append("&");
	    }
	    return postData.append(
	            String.format("%s=%s",
	                    URLEncoder.encode(param, StandardCharsets.UTF_8.displayName()),
	                    URLEncoder.encode(value, StandardCharsets.UTF_8.displayName())));
	  }

}
