package pe.gob.osce.seguridad.seace.dto;

import java.util.Date;
import java.util.List;

import pe.gob.osce.seguridad.seace.enums.EstadoState;
import pe.gob.osce.seguridad.utils.DataTransferObjectUtil;

public class PrivilegioDto extends DataTransferObjectUtil {

	private static final long serialVersionUID = 1L;

	private Long id;
	
	private String accion;
	
	private String nombre;
	
	private String descripcion;

	private String estado;

	private Date fechaCreacion;
	
	private String usuarioCreacion;
	
	private Date ultimaFechaModificacion;
	
	private String ultimoUsuarioModificacion;
	
	private Date ultimaFechaActivacion;
	
	private String ultimoUsuarioActivacion;

	private Date ultimaFechaDesactivacion;
	
	private String ultimoUsuarioDesactivacion;

	private ModuloDto modulo = new ModuloDto();
	
	private String nombreModulo;

	private List<PrivilegioRolDto> listaPrivilegioRol;
	
	private EstadoState estadoPrivilegio;

	private String action;

	private Long rolId;
  
	public String getNombreModulo() {
		return nombreModulo;
	}

	public void setNombreModulo(String nombreModulo) {
		this.nombreModulo = nombreModulo;
	}
	
    public String getAction() {
		return action;
	}

    public void setAction(String action) {
		this.action = action;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getAccion() {
		return accion;
	}

	public void setAccion(String accion) {
		this.accion = accion;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public String getEstado() {
		return estado;
	}

	public void setEstado(String estado) {
		this.estadoPrivilegio = EstadoState.get(estado);
		this.estado = estado;
	}

    @Override
	public Date getFechaCreacion() {
		return fechaCreacion;
	}

    @Override
	public void setFechaCreacion(Date fechaCreacion) {
		this.fechaCreacion = fechaCreacion;
	}

	public String getUsuarioCreacion() {
		return usuarioCreacion;
	}

	public void setUsuarioCreacion(String usuarioCreacion) {
		this.usuarioCreacion = usuarioCreacion;
	}

	public Date getUltimaFechaModificacion() {
		return ultimaFechaModificacion;
	}

	public void setUltimaFechaModificacion(Date ultimaFechaModificacion) {
		this.ultimaFechaModificacion = ultimaFechaModificacion;
	}

	public String getUltimoUsuarioModificacion() {
		return ultimoUsuarioModificacion;
	}
	public void setUltimoUsuarioModificacion(String ultimoUsuarioModificacion) {
		this.ultimoUsuarioModificacion = ultimoUsuarioModificacion;
	}

	public Date getUltimaFechaActivacion() {
		return ultimaFechaActivacion;
	}

	public void setUltimaFechaActivacion(Date ultimaFechaActivacion) {
		this.ultimaFechaActivacion = ultimaFechaActivacion;
	}

	public String getUltimoUsuarioActivacion() {
		return ultimoUsuarioActivacion;
	}

	public void setUltimoUsuarioActivacion(String ultimoUsuarioActivacion) {
		this.ultimoUsuarioActivacion = ultimoUsuarioActivacion;
	}

	public Date getUltimaFechaDesactivacion() {
		return ultimaFechaDesactivacion;
	}

	public void setUltimaFechaDesactivacion(Date ultimaFechaDesactivacion) {
		this.ultimaFechaDesactivacion = ultimaFechaDesactivacion;
	}

	public String getUltimoUsuarioDesactivacion() {
		return ultimoUsuarioDesactivacion;
	}

	public void setUltimoUsuarioDesactivacion(String ultimoUsuarioDesactivacion) {
		this.ultimoUsuarioDesactivacion = ultimoUsuarioDesactivacion;
	}

	public ModuloDto getModulo() {
		return modulo;
	}

	public void setModulo(ModuloDto modulo) {
		this.modulo = modulo;
	}

	public List<PrivilegioRolDto> getListaPrivilegioRol() {
		return listaPrivilegioRol;
	}

	public void setListaPrivilegioRol(List<PrivilegioRolDto> listaPrivilegioRol) {
		this.listaPrivilegioRol = listaPrivilegioRol;
	}

	public EstadoState getEstadoPrivilegio() {
		return estadoPrivilegio;
	}

	public void setEstadoPrivilegio(EstadoState estadoPrivilegio) {
		this.estadoPrivilegio = estadoPrivilegio;
	}

	public Long getRolId() {
		return rolId;
	}

	public void setRolId(Long rolId) {
		this.rolId = rolId;
	}
}